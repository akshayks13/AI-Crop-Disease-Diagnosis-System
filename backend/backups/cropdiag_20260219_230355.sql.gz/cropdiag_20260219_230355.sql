--
-- PostgreSQL database dump
--

\restrict 7xPZWawhW4hPBSz9vfB3p07EC9FHKPjenNdt0aMUl0b1ay8P7ASbzyR2D7ePUOg

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: growthstage; Type: TYPE; Schema: public; Owner: akshayks
--

CREATE TYPE public.growthstage AS ENUM (
    'GERMINATION',
    'SEEDLING',
    'VEGETATIVE',
    'FLOWERING',
    'FRUITING',
    'RIPENING',
    'HARVEST'
);


ALTER TYPE public.growthstage OWNER TO akshayks;

--
-- Name: taskpriority; Type: TYPE; Schema: public; Owner: akshayks
--

CREATE TYPE public.taskpriority AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


ALTER TYPE public.taskpriority OWNER TO akshayks;

--
-- Name: trendtype; Type: TYPE; Schema: public; Owner: akshayks
--

CREATE TYPE public.trendtype AS ENUM (
    'UP',
    'DOWN',
    'STABLE'
);


ALTER TYPE public.trendtype OWNER TO akshayks;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agronomy_diagnostic_rules; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.agronomy_diagnostic_rules (
    id uuid NOT NULL,
    disease_id uuid NOT NULL,
    rule_name character varying(100) NOT NULL,
    description text,
    conditions jsonb NOT NULL,
    impact jsonb NOT NULL,
    priority double precision,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.agronomy_diagnostic_rules OWNER TO akshayks;

--
-- Name: agronomy_seasonal_patterns; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.agronomy_seasonal_patterns (
    id uuid NOT NULL,
    disease_id uuid NOT NULL,
    crop_id uuid NOT NULL,
    region character varying(100),
    season character varying(50) NOT NULL,
    likelihood_score double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.agronomy_seasonal_patterns OWNER TO akshayks;

--
-- Name: agronomy_treatment_constraints; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.agronomy_treatment_constraints (
    id uuid NOT NULL,
    treatment_name character varying(200) NOT NULL,
    treatment_type character varying(50) NOT NULL,
    constraint_description text NOT NULL,
    restricted_conditions jsonb NOT NULL,
    enforcement_level character varying(50),
    risk_level character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.agronomy_treatment_constraints OWNER TO akshayks;

--
-- Name: answers; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.answers (
    id uuid NOT NULL,
    question_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    answer_text text NOT NULL,
    rating integer,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.answers OWNER TO akshayks;

--
-- Name: community_comments; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.community_comments (
    id uuid NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.community_comments OWNER TO akshayks;

--
-- Name: community_posts; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.community_posts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    image_path character varying(500),
    likes_count integer,
    comments_count integer,
    is_pinned boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    category character varying(50) DEFAULT 'general'::character varying,
    is_expert_post boolean DEFAULT false
);


ALTER TABLE public.community_posts OWNER TO akshayks;

--
-- Name: crop_encyclopedia; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.crop_encyclopedia (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    scientific_name character varying(200),
    description text,
    season character varying(100),
    temp_min double precision,
    temp_max double precision,
    water_requirement character varying(50),
    soil_type character varying(200),
    growing_tips jsonb,
    nutritional_info jsonb,
    common_varieties jsonb,
    common_diseases jsonb,
    image_url character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.crop_encyclopedia OWNER TO akshayks;

--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.daily_stats (
    id uuid NOT NULL,
    date timestamp without time zone NOT NULL,
    total_diagnoses integer NOT NULL,
    total_questions integer NOT NULL,
    total_answers integer NOT NULL,
    new_users integer NOT NULL,
    active_users integer NOT NULL,
    avg_confidence double precision,
    error_count integer NOT NULL
);


ALTER TABLE public.daily_stats OWNER TO akshayks;

--
-- Name: diagnoses; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.diagnoses (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    media_path character varying(500) NOT NULL,
    media_type character varying(20) NOT NULL,
    crop_type character varying(100),
    location character varying(255),
    disease character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    confidence double precision NOT NULL,
    treatment json NOT NULL,
    prevention text,
    warnings text,
    additional_diseases json,
    created_at timestamp without time zone NOT NULL,
    rating integer
);


ALTER TABLE public.diagnoses OWNER TO akshayks;

--
-- Name: disease_encyclopedia; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.disease_encyclopedia (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    scientific_name character varying(200),
    affected_crops jsonb,
    description text,
    symptoms jsonb,
    causes text,
    chemical_treatment jsonb,
    organic_treatment jsonb,
    prevention jsonb,
    severity_level character varying(50),
    spread_method character varying(200),
    safety_warnings jsonb,
    environmental_warnings jsonb,
    image_url character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.disease_encyclopedia OWNER TO akshayks;

--
-- Name: farm_crops; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.farm_crops (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    crop_type character varying(100) NOT NULL,
    field_name character varying(100),
    area_size double precision,
    area_unit character varying(20),
    sow_date date NOT NULL,
    expected_harvest_date date,
    growth_stage public.growthstage,
    progress double precision,
    notes text,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.farm_crops OWNER TO akshayks;

--
-- Name: farm_tasks; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.farm_tasks (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    crop_id uuid,
    title character varying(255) NOT NULL,
    description text,
    due_date timestamp without time zone,
    priority public.taskpriority,
    is_completed boolean,
    completed_at timestamp without time zone,
    is_recurring boolean,
    recurrence_days integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.farm_tasks OWNER TO akshayks;

--
-- Name: market_prices; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.market_prices (
    id uuid NOT NULL,
    commodity character varying(100) NOT NULL,
    price double precision NOT NULL,
    unit character varying(50),
    location character varying(255) NOT NULL,
    trend public.trendtype,
    change_percent double precision,
    min_price double precision,
    max_price double precision,
    arrival_qty double precision,
    recorded_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.market_prices OWNER TO akshayks;

--
-- Name: pest_encyclopedia; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.pest_encyclopedia (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    scientific_name character varying(200),
    affected_crops jsonb,
    description text,
    symptoms jsonb,
    appearance text,
    damage_type character varying(100),
    life_cycle text,
    control_methods jsonb,
    organic_control jsonb,
    chemical_control jsonb,
    prevention jsonb,
    severity_level character varying(50),
    image_url character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pest_encyclopedia OWNER TO akshayks;

--
-- Name: post_likes; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.post_likes (
    id uuid NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.post_likes OWNER TO akshayks;

--
-- Name: questions; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.questions (
    id uuid NOT NULL,
    farmer_id uuid NOT NULL,
    media_path character varying(500),
    question_text text NOT NULL,
    diagnosis_id uuid,
    status character varying(8) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.questions OWNER TO akshayks;

--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.system_logs (
    id uuid NOT NULL,
    level character varying(20) NOT NULL,
    message text NOT NULL,
    source character varying(100),
    user_id uuid,
    log_metadata json,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_logs OWNER TO akshayks;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.system_metrics (
    id uuid NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value double precision NOT NULL,
    metric_type character varying(50) NOT NULL,
    tags json,
    recorded_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_metrics OWNER TO akshayks;

--
-- Name: users; Type: TABLE; Schema: public; Owner: akshayks
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    phone character varying(20),
    role character varying(6) NOT NULL,
    status character varying(9) NOT NULL,
    is_verified boolean NOT NULL,
    otp_code character varying(6),
    otp_created_at timestamp without time zone,
    expertise_domain character varying(255),
    qualification text,
    experience_years integer,
    location character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO akshayks;

--
-- Data for Name: agronomy_diagnostic_rules; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.agronomy_diagnostic_rules (id, disease_id, rule_name, description, conditions, impact, priority, is_active, created_at, updated_at) FROM stdin;
87e45e6d-0dba-4d28-bc82-8e397bbf9137	9e5313a8-16c5-4c42-9e71-f390f3d55cd4	Warm Humid Conditions Favorable	Early Blight thrives in warm (20-30°C) and humid (70%+) conditions	{"temp_max": 30, "temp_min": 20, "humidity_min": 70}	{"confidence_boost": 0.1, "confidence_penalty": -0.15}	1	t	2026-02-08 07:32:09.13302	2026-02-08 07:32:09.133021
d7d17e4e-7caa-447a-abc6-1264a1cfbd37	9e5313a8-16c5-4c42-9e71-f390f3d55cd4	Kharif Season Prevalence	More common during Kharif (monsoon) season	{"season": "Kharif"}	{"confidence_boost": 0.05, "confidence_penalty": -0.05}	0.8	t	2026-02-08 07:32:09.133026	2026-02-08 07:32:09.133027
fb428431-5e7c-4b9f-864b-7800bcf8302f	18b74f3e-84df-4854-abd9-4c6abccfec4d	Cool Wet Conditions Required	Late Blight requires cool temps (10-25°C) and high moisture	{"temp_max": 25, "temp_min": 10, "humidity_min": 80}	{"confidence_boost": 0.15, "confidence_penalty": -0.2}	1.2	t	2026-02-08 07:32:09.133031	2026-02-08 07:32:09.133031
89ffb609-0b64-4f46-871a-c237f9a56dd1	18b74f3e-84df-4854-abd9-4c6abccfec4d	Rainy Weather Critical	Spreads rapidly during rainy periods	{"season": "Kharif"}	{"confidence_boost": 0.1, "confidence_penalty": -0.1}	1	t	2026-02-08 07:32:09.133036	2026-02-08 07:32:09.133036
384a4aa5-214b-47ce-8a57-1223cef891b3	624f3b7f-8e15-4b55-a3df-05e9ff282111	Warm Dry Conditions	Powdery Mildew prefers warm (20-30°C) and dry (<60% humidity) conditions	{"temp_max": 30, "temp_min": 20, "humidity_max": 60}	{"confidence_boost": 0.1, "confidence_penalty": -0.1}	0.9	t	2026-02-08 07:32:09.13304	2026-02-08 07:32:09.13304
\.


--
-- Data for Name: agronomy_seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.agronomy_seasonal_patterns (id, disease_id, crop_id, region, season, likelihood_score, created_at, updated_at) FROM stdin;
968c5725-f143-451f-bc0f-813569792968	9e5313a8-16c5-4c42-9e71-f390f3d55cd4	1881bc85-d8f5-4488-a003-acefe23faee2	Karnataka	Kharif	0.75	2026-02-08 07:32:09.142461	2026-02-08 07:32:09.142465
1cb7d2f0-9609-43a4-a5a5-7aebc9fd5135	18b74f3e-84df-4854-abd9-4c6abccfec4d	1881bc85-d8f5-4488-a003-acefe23faee2	Karnataka	Kharif	0.85	2026-02-08 07:32:09.14247	2026-02-08 07:32:09.14247
7dde36dd-3f16-4a98-9d53-ff3433a8b56c	18b74f3e-84df-4854-abd9-4c6abccfec4d	1881bc85-d8f5-4488-a003-acefe23faee2	\N	Kharif	0.7	2026-02-08 07:32:09.142475	2026-02-08 07:32:09.142475
e5592638-db6c-4a0a-8e06-6d05ccf913b6	18b74f3e-84df-4854-abd9-4c6abccfec4d	ab5b1744-1632-4e98-bade-8e8b92c7868a	\N	Rabi	0.8	2026-02-08 07:32:09.142479	2026-02-08 07:32:09.14248
51e8d866-46dc-42de-b88f-c2c4b8f2a01d	18b74f3e-84df-4854-abd9-4c6abccfec4d	ab5b1744-1632-4e98-bade-8e8b92c7868a	Karnataka	Rabi	0.75	2026-02-08 07:32:09.142484	2026-02-08 07:32:09.142484
9d27bb21-aebb-4c57-9082-fef4381b4527	624f3b7f-8e15-4b55-a3df-05e9ff282111	b41298e7-41ef-49e3-86d3-c8106f1d7c93	\N	Rabi	0.6	2026-02-08 07:32:09.142488	2026-02-08 07:32:09.142488
\.


--
-- Data for Name: agronomy_treatment_constraints; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.agronomy_treatment_constraints (id, treatment_name, treatment_type, constraint_description, restricted_conditions, enforcement_level, risk_level, created_at, updated_at) FROM stdin;
4265e1da-81c3-4e72-aeab-e432e225f3bf	Mancozeb 75% WP	chemical	Avoid spraying during rain or within 3 hours of expected rainfall	{"weather": "rainy"}	warn	medium	2026-02-08 07:32:09.149851	2026-02-08 07:32:09.149855
34e957fc-2c37-449a-ba4a-24ea26078012	Copper Fungicide	chemical	Do NOT apply during rainy weather - rain will wash away and contaminate soil	{"weather": "rainy"}	block	high	2026-02-08 07:32:09.14986	2026-02-08 07:32:09.149861
0a202a24-9fbc-449e-ad7d-2215150c6fc0	Metalaxyl	chemical	Not recommended for sandy soils due to leaching risk	{"soil_type": "sandy"}	warn	medium	2026-02-08 07:32:09.149865	2026-02-08 07:32:09.149865
f07444d4-77d7-4b25-a500-9ba4e92af352	Neem Oil	organic	Apply in early morning or evening to avoid leaf burn in hot sun	{"temperature_max": 35}	warn	low	2026-02-08 07:32:09.14987	2026-02-08 07:32:09.14987
4edd467d-07a8-4701-bdb3-8ab35b10c220	Sulphur	chemical	Do not apply when temperature exceeds 32°C - risk of phytotoxicity	{"temperature_max": 32}	warn	medium	2026-02-08 07:32:09.149874	2026-02-08 07:32:09.149875
\.


--
-- Data for Name: answers; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.answers (id, question_id, expert_id, answer_text, rating, created_at) FROM stdin;
73e1101c-06f6-4919-8286-aedfea1243cf	37c7e1ad-40c7-4ade-a92c-6419206f728e	ad4863d1-3073-4606-8100-999fe3b3942e	mm ok i will help	\N	2026-02-04 06:47:51.29384
526783c1-afa7-43f1-b5f3-48d9a6d643c9	e6d10075-d8bc-44f3-9325-398538e30c85	ad4863d1-3073-4606-8100-999fe3b3942e	hello , this is easy to fix	3	2026-02-04 06:44:53.736782
608bcf9a-5edf-4cc3-b9d7-7053697d1d08	1a825cd9-fbb3-4027-9a8b-59484183d505	ad4863d1-3073-4606-8100-999fe3b3942e	Based on your description, this sounds like **Early Blight** caused by the fungus *Alternaria solani*.\n\n**Immediate Treatment:**\n1. Remove and destroy infected leaves\n2. Apply Mancozeb 75% WP (2.5g/L of water) spray\n3. Repeat every 7-10 days\n\n**Organic Alternative:**\n- Neem oil spray (5ml/L water)\n- Copper fungicide\n\n**Prevention:**\n- Ensure proper plant spacing for air circulation\n- Water at the base, not on leaves\n- Practice crop rotation\n\nYour plants should recover within 2-3 weeks with proper treatment.	2	2026-01-27 14:23:14.728056
f4470e3a-ea2f-424e-865f-ace65032eef0	f2759a4e-2c86-44cc-bd20-c1acdfe283a2	ad4863d1-3073-4606-8100-999fe3b3942e	ok this is something bad	4	2026-02-09 09:06:51.072138
\.


--
-- Data for Name: community_comments; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.community_comments (id, post_id, user_id, content, created_at) FROM stdin;
86b1b4d9-f870-4ac3-8d16-dc6a4b4f26ff	4f490e54-8363-403b-932c-a3ab29abf077	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	yes , this is true	2026-02-04 05:50:40.138153
67e2b24b-0a21-451b-a1cc-5ef780858475	efa163c4-4982-4e89-afb1-e55e7f31f33b	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	hi	2026-02-07 14:32:47.202934
\.


--
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.community_posts (id, user_id, title, content, image_path, likes_count, comments_count, is_pinned, created_at, updated_at, category, is_expert_post) FROM stdin;
4f490e54-8363-403b-932c-a3ab29abf077	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	hiamamma	hellooommmama	\N	1	1	f	2026-02-04 05:50:31.541809	2026-02-04 05:50:40.136146	general	f
efad3fd6-2383-45c3-b027-e5564f5ee750	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	helllwwllwlwwllw	alaaaamamamamama	\N	0	0	f	2026-02-04 06:33:45.126308	2026-02-04 06:33:45.126312	general	f
efa163c4-4982-4e89-afb1-e55e7f31f33b	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	thispost	hellowwwwww	\N	0	1	f	2026-02-07 14:11:16.381697	2026-02-07 14:32:47.195672	general	f
6311f7cd-1c0c-425b-8eea-bda214ed8c67	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	abchde	abcdefghijklmw	/uploads/community/6ea2f02b-c850-4c7d-8c72-70ffb68ce86d.png	1	0	f	2026-02-07 14:45:58.17342	2026-02-07 14:46:01.80276	general	f
23260071-7084-4486-83d3-830aeb8df450	ad4863d1-3073-4606-8100-999fe3b3942e	Hello	Hi , i am a expert i know all	\N	0	0	f	2026-02-09 13:08:18.476461	2026-02-09 13:08:18.476464	tip	t
\.


--
-- Data for Name: crop_encyclopedia; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.crop_encyclopedia (id, name, scientific_name, description, season, temp_min, temp_max, water_requirement, soil_type, growing_tips, nutritional_info, common_varieties, common_diseases, image_url, created_at, updated_at) FROM stdin;
1881bc85-d8f5-4488-a003-acefe23faee2	Tomato	Solanum lycopersicum	\N	Rabi & Kharif	20	25	Medium	Loamy, well-drained	["Stake plants for support", "Prune suckers regularly"]	{}	[]	["Early Blight", "Late Blight", "Leaf Curl"]	\N	2026-01-31 14:23:14.73371	2026-01-31 14:23:14.733711
ab5b1744-1632-4e98-bade-8e8b92c7868a	Potato	Solanum tuberosum	\N	Rabi	15	20	Medium	Sandy loam	["Hill soil around plants", "Avoid overwatering"]	{}	[]	["Late Blight", "Black Scurf"]	\N	2026-01-31 14:23:14.733716	2026-01-31 14:23:14.733716
b41298e7-41ef-49e3-86d3-c8106f1d7c93	Wheat	Triticum aestivum	\N	Rabi	10	25	Medium	Clay loam	["Ensure proper irrigation at flowering stage"]	{}	[]	["Rust", "Powdery Mildew"]	\N	2026-01-31 14:23:14.73372	2026-01-31 14:23:14.733721
f7a55273-6822-48e7-ad31-b53c9a556d3d	Rice	Oryza sativa	\N	Kharif	20	35	High	Clay, alluvial	["Maintain standing water in paddy fields"]	{}	[]	["Blast", "Bacterial Leaf Blight"]	\N	2026-01-31 14:23:14.733725	2026-01-31 14:23:14.733725
71b7c9e4-531b-4c4b-8d93-9ec43d2c3a14	Cotton	Gossypium	\N	Kharif	20	30	Medium	Black cotton soil	["Control bollworm early in season"]	{}	[]	["Boll Rot", "Leaf Curl"]	\N	2026-01-31 14:23:14.733729	2026-01-31 14:23:14.733729
7e68968e-f0d8-4af9-ac6a-c6593d20393c	Corn	Zea mays	\N	Kharif	18	27	Medium to High	Loamy	["Plant in blocks for better pollination"]	{}	[]	["Maize Streak Virus", "Rust"]	\N	2026-01-31 14:23:14.733733	2026-01-31 14:23:14.733733
\.


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.daily_stats (id, date, total_diagnoses, total_questions, total_answers, new_users, active_users, avg_confidence, error_count) FROM stdin;
\.


--
-- Data for Name: diagnoses; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.diagnoses (id, user_id, media_path, media_type, crop_type, location, disease, severity, confidence, treatment, prevention, warnings, additional_diseases, created_at, rating) FROM stdin;
717eacd4-0c68-412f-94f2-60373151a7f2	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260204_061657_b14ad69e.png	image	\N	\N	Viral Infection	moderate	0.877	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Nutrient Deficiency", "confidence": 0.074}, {"disease": "Fungal Infection", "confidence": 0.049}]}	2026-02-04 06:16:57.909438	\N
1948a1cf-429d-4be4-b79f-0df8970ba6ec	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260204_061337_764f6f36.png	image	\N	\N	Fungal Infection	moderate	0.831	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Nutrient Deficiency", "confidence": 0.101}, {"disease": "Healthy", "confidence": 0.067}]}	2026-02-04 06:13:37.262383	2
eb2a2719-4d8e-4f4a-ab47-cce8b7186c19	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260208_072126_8a0ff9df.png	image	\N	\N	Viral Infection	moderate	0.827	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Bacterial Infection", "confidence": 0.104}, {"disease": "Fungal Infection", "confidence": 0.069}]}	2026-02-08 07:21:26.104553	\N
696fd703-b87e-4c02-b616-38251a6f3c61	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260208_072146_b308204c.png	image	\N	\N	Pest Damage	severe	0.797	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "Immediately"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 24 hours"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 24 hours"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 24 hours"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	⚠️ URGENT: Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Nutrient Deficiency", "confidence": 0.122}, {"disease": "Bacterial Infection", "confidence": 0.081}]}	2026-02-08 07:21:46.877711	\N
55da9d22-1c5c-4340-8043-c48e5492e3f8	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260208_074833_8cafc149.png	image	\N	\N	Bacterial Infection	severe	0.864	{"steps": [{"step_number": 1, "description": "Remove and destroy infected plants", "timing": "Immediately"}, {"step_number": 2, "description": "Disinfect tools after use", "timing": "Within 24 hours"}, {"step_number": 3, "description": "Apply copper-based bactericide", "timing": "Within 24 hours"}, {"step_number": 4, "description": "Avoid working with plants when wet", "timing": "Within 24 hours"}], "chemical": [{"name": "Streptomycin Sulphate", "dosage": "0.5 g/L water", "application": "Foliar spray", "frequency": "Every 7-10 days"}], "organic": [{"name": "Copper Oxychloride", "dosage": "3 g/L water", "application": "Foliar spray", "frequency": "Weekly"}], "description": "Bacterial disease causing spots, wilting, or rot", "prevention": "Use disease-free seeds, practice sanitation, avoid plant injuries"}	Use disease-free seeds, practice sanitation, avoid plant injuries	⚠️ URGENT: Bacterial diseases spread easily through water and tools	{"predictions": [{"disease": "Nutrient Deficiency", "confidence": 0.081}, {"disease": "Healthy", "confidence": 0.054}]}	2026-02-08 07:48:33.56294	\N
ab33d868-bef3-425d-9620-d1967a0cc97c	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	/uploads/images/77e5e0cc-8d0a-42c3-b162-904cfbc8896f_20260209_161237_41d517c1.jpeg	image	\N	\N	Pest Damage	severe	0.929	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "Immediately"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 24 hours"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 24 hours"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 24 hours"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	⚠️ URGENT: Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Bacterial Infection", "confidence": 0.042}, {"disease": "Viral Infection", "confidence": 0.028}]}	2026-02-09 16:12:37.231329	\N
d6285fdb-cb8d-463b-b9a7-b8493da8fee4	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	/uploads/images/77e5e0cc-8d0a-42c3-b162-904cfbc8896f_20260209_161255_15298a73.jpeg	image	\N	\N	Nutrient Deficiency	mild	0.903	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "When convenient"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within a week"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within a week"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within a week"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Viral Infection", "confidence": 0.058}, {"disease": "Fungal Infection", "confidence": 0.039}]}	2026-02-09 16:12:55.166335	\N
ade40e82-5d79-4e32-a43a-134f7a32fe61	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260210_045948_50e9c043.jpeg	image	\N	\N	Viral Infection	moderate	0.952	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Healthy", "confidence": 0.029}, {"disease": "Nutrient Deficiency", "confidence": 0.019}]}	2026-02-10 04:59:48.787756	\N
ceb987b1-c285-4bba-92b2-f538775bc612	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260210_051257_efbd8c4b.jpeg	image	\N	\N	Bacterial Infection	moderate	0.881	{"steps": [{"step_number": 1, "description": "Remove and destroy infected plants", "timing": "As soon as possible"}, {"step_number": 2, "description": "Disinfect tools after use", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Apply copper-based bactericide", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid working with plants when wet", "timing": "Within 2-3 days"}], "chemical": [{"name": "Streptomycin Sulphate", "dosage": "0.5 g/L water", "application": "Foliar spray", "frequency": "Every 7-10 days"}], "organic": [{"name": "Copper Oxychloride", "dosage": "3 g/L water", "application": "Foliar spray", "frequency": "Weekly"}], "description": "Bacterial disease causing spots, wilting, or rot", "prevention": "Use disease-free seeds, practice sanitation, avoid plant injuries"}	Use disease-free seeds, practice sanitation, avoid plant injuries	Bacterial diseases spread easily through water and tools	{"predictions": [{"disease": "Pest Damage", "confidence": 0.072}, {"disease": "Nutrient Deficiency", "confidence": 0.048}]}	2026-02-10 05:12:57.781142	\N
fdae5c83-bf12-4476-afc0-cb691312ec0c	1ddb77c7-5db3-4d9b-837b-2dd5bb76cb98	/uploads/images/1ddb77c7-5db3-4d9b-837b-2dd5bb76cb98_20260210_093016_c78d64fa.jpeg	image	\N	\N	Viral Infection	moderate	0.95	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Bacterial Infection", "confidence": 0.03}, {"disease": "Nutrient Deficiency", "confidence": 0.02}]}	2026-02-10 09:30:16.484276	\N
cbbc8ef3-8846-4c6b-a151-90fea20a5851	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260218_055233_f403444b.png	image	\N	\N	Fungal Infection	moderate	0.869	{"steps": [{"step_number": 1, "description": "Identify and remove infected parts", "timing": "As soon as possible"}, {"step_number": 2, "description": "Apply appropriate fungicide", "timing": "Within 2-3 days"}, {"step_number": 3, "description": "Improve drainage and air circulation", "timing": "Within 2-3 days"}, {"step_number": 4, "description": "Avoid overhead watering", "timing": "Within 2-3 days"}], "chemical": [{"name": "Carbendazim", "dosage": "1 g/L water", "application": "Foliar spray", "frequency": "Every 10-14 days"}], "organic": [{"name": "Trichoderma viride", "dosage": "5 g/L water", "application": "Soil drench and foliar", "frequency": "Every 15 days"}], "description": "General fungal disease affecting plant tissues", "prevention": "Crop rotation, proper spacing, balanced nutrition"}	Crop rotation, proper spacing, balanced nutrition	Consult local agricultural expert for specific identification	{"predictions": [{"disease": "Bacterial Infection", "confidence": 0.078}, {"disease": "Healthy", "confidence": 0.052}]}	2026-02-18 05:52:33.791074	\N
\.


--
-- Data for Name: disease_encyclopedia; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.disease_encyclopedia (id, name, scientific_name, affected_crops, description, symptoms, causes, chemical_treatment, organic_treatment, prevention, severity_level, spread_method, safety_warnings, environmental_warnings, image_url, created_at, updated_at) FROM stdin;
9e5313a8-16c5-4c42-9e71-f390f3d55cd4	Early Blight	\N	["Tomato", "Potato"]	Fungal disease causing dark spots with concentric rings on leaves.	["Dark brown spots", "Yellow halos", "Lower leaf infection first"]	Fungus Alternaria solani, spreads in warm humid conditions	["Mancozeb 75% WP", "Chlorothalonil"]	["Neem oil spray", "Copper fungicides"]	["Crop rotation", "Remove infected debris", "Proper spacing"]	moderate	\N	[]	[]	\N	2026-01-31 14:23:14.736775	2026-01-31 14:23:14.736778
18b74f3e-84df-4854-abd9-4c6abccfec4d	Late Blight	\N	["Tomato", "Potato"]	Devastating disease causing rapid plant death in wet conditions.	["Water-soaked lesions", "White fuzzy growth", "Rapid browning"]	Oomycete Phytophthora infestans	["Metalaxyl", "Cymoxanil"]	["Bordeaux mixture"]	["Use resistant varieties", "Good drainage", "Avoid overhead irrigation"]	severe	\N	["Apply fungicide before rain expected"]	[]	\N	2026-01-31 14:23:14.738318	2026-01-31 14:23:14.738318
624f3b7f-8e15-4b55-a3df-05e9ff282111	Powdery Mildew	\N	["Wheat", "Cucumber", "Grapes"]	White powdery fungal growth on leaves and stems.	["White powder on leaves", "Yellowing", "Stunted growth"]	\N	["Sulphur", "Triadimefon"]	["Milk spray", "Baking soda solution"]	["Good air circulation", "Avoid overcrowding"]	mild	\N	[]	[]	\N	2026-01-31 14:23:14.738839	2026-01-31 14:23:14.73884
\.


--
-- Data for Name: farm_crops; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.farm_crops (id, user_id, name, crop_type, field_name, area_size, area_unit, sow_date, expected_harvest_date, growth_stage, progress, notes, is_active, created_at, updated_at) FROM stdin;
119fdfbd-a03a-47dd-9d66-01f86421dc13	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	hello	byee	\N	\N	acres	2026-02-04	\N	GERMINATION	0	\N	t	2026-02-04 05:42:55.377728	2026-02-04 05:42:55.377731
1838921f-f5f2-4aa3-aa4e-9c463834358b	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	Winter Wheat	Wheat	North Field	2.5	acre	2025-12-27	2026-04-26	VEGETATIVE	40	Healthy growth, applied urea last week.	t	2026-02-10 04:43:31.194853	2026-02-10 04:43:31.194855
412dba28-f633-4012-a7f0-cf60e82cbc3c	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	Basmati Rice	Rice	Wetland Block A	5	hectare	2025-10-23	2026-02-20	RIPENING	90	Ready for harvest soon. Water drained.	t	2026-02-10 04:43:31.226498	2026-02-10 04:43:31.226499
a5a45699-f9fe-4a18-9905-30bd4182d98f	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	Hybrid Tomato	Tomato	Greenhouse 1	0.5	acre	2026-02-05	2026-05-06	GERMINATION	5	Varieties: Roma and Cherry	t	2026-02-10 04:43:31.244106	2026-02-10 04:43:31.244107
\.


--
-- Data for Name: farm_tasks; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.farm_tasks (id, user_id, crop_id, title, description, due_date, priority, is_completed, completed_at, is_recurring, recurrence_days, created_at, updated_at) FROM stdin;
9448d171-a223-4c1b-9ed0-34745aa11511	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	1838921f-f5f2-4aa3-aa4e-9c463834358b	Apply Pesticide	Spray for aphids prevention	2026-02-12 10:13:31.226086	HIGH	f	\N	f	\N	2026-02-10 04:43:31.227721	2026-02-10 04:43:31.227721
3c212cfe-ac69-4669-8654-3d5643081f9a	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	412dba28-f633-4012-a7f0-cf60e82cbc3c	Prepare Thresher	Service the thresher machine before harvest	2026-02-11 10:13:31.24367	MEDIUM	t	2026-02-10 04:54:36.553962	f	\N	2026-02-10 04:43:31.244674	2026-02-10 04:54:36.553967
\.


--
-- Data for Name: market_prices; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.market_prices (id, commodity, price, unit, location, trend, change_percent, min_price, max_price, arrival_qty, recorded_at, created_at, updated_at) FROM stdin;
3f731ee8-14c6-4ade-9364-71da3b9b439c	Tomato	2500	Quintal	Kolar Mandi	UP	5	\N	\N	\N	2026-01-31 14:23:14.754968	2026-01-31 14:23:14.75497	2026-01-31 14:23:14.75497
6106ac5b-46e9-43ba-8e8b-b8e97fa1d068	Potato	1800	Quintal	Hassan Mandi	DOWN	-2	\N	\N	\N	2026-01-31 14:23:14.754975	2026-01-31 14:23:14.754975	2026-01-31 14:23:14.754976
d18466eb-eae4-4f2c-9f88-b9cd7e478a0d	Onion	3200	Quintal	Yeshwanthpur	UP	8	\N	\N	\N	2026-01-31 14:23:14.75498	2026-01-31 14:23:14.75498	2026-01-31 14:23:14.75498
6843b98a-29ea-4bf1-9cac-7834d07c7e62	Green Chilli	4500	Quintal	Chikkaballapur	STABLE	0	\N	\N	\N	2026-01-31 14:23:14.754984	2026-01-31 14:23:14.754985	2026-01-31 14:23:14.754985
84775edb-227f-4ee9-a0bd-9ba98d06c59b	Wheat	2100	Quintal	Belgaum	UP	1	\N	\N	\N	2026-01-31 14:23:14.754989	2026-01-31 14:23:14.754989	2026-01-31 14:23:14.754989
3e482061-de0f-4514-b2e4-ce321fde6cc2	Rice (Sona Masoori)	4800	Quintal	Raichur	DOWN	-1.5	\N	\N	\N	2026-01-31 14:23:14.754993	2026-01-31 14:23:14.754994	2026-01-31 14:23:14.754994
c89356c4-6cb6-4b4b-8f06-e0ca3cd56f5d	Cotton	6200	Quintal	Haveri	UP	3	\N	\N	\N	2026-01-31 14:23:14.754998	2026-01-31 14:23:14.754998	2026-01-31 14:23:14.754998
f38db190-5042-42e8-8984-9a6c33bd7fd9	Maize	1950	Quintal	Davangere	STABLE	0	\N	\N	\N	2026-01-31 14:23:14.755002	2026-01-31 14:23:14.755002	2026-01-31 14:23:14.755003
0d3b48cb-2055-4d2e-9128-c55d1e5e60f1	Tur Dal	8500	Quintal	Kalaburagi	UP	10	\N	\N	\N	2026-01-31 14:23:14.755007	2026-01-31 14:23:14.755007	2026-01-31 14:23:14.755007
b3580b6d-c396-4b4a-a768-ae34c207770c	Groundnut	5600	Quintal	Chitradurga	DOWN	-4	\N	\N	\N	2026-01-31 14:23:14.755011	2026-01-31 14:23:14.755011	2026-01-31 14:23:14.755011
\.


--
-- Data for Name: pest_encyclopedia; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.pest_encyclopedia (id, name, scientific_name, affected_crops, description, symptoms, appearance, damage_type, life_cycle, control_methods, organic_control, chemical_control, prevention, severity_level, image_url, created_at, updated_at) FROM stdin;
b99733f9-08fe-4d16-9252-fdea9bf7c0d7	Aphids	Aphididae	["Tomato", "Cotton", "Wheat", "Mustard", "Potato"]	Tiny soft-bodied insects that cluster on new growth and undersides of leaves, sucking plant sap and transmitting viruses.	["Curled or distorted leaves", "Sticky honeydew on leaves", "Yellowing", "Stunted growth", "Sooty mold growth"]	Tiny (1-3mm), pear-shaped, green/black/yellow, often in clusters	Sucking	Reproduce rapidly; 20-30 generations per year. Wingless in summer, winged forms appear when overcrowded.	["Monitor regularly", "Use yellow sticky traps", "Encourage natural predators like ladybugs"]	["Neem oil spray (5ml/L)", "Soap water spray", "Release ladybird beetles"]	["Imidacloprid 17.8 SL @ 0.5ml/L", "Dimethoate 30 EC @ 2ml/L"]	["Avoid excessive nitrogen fertilizer", "Intercrop with coriander or marigold", "Remove weeds"]	moderate	\N	2026-02-18 06:18:38.058105	2026-02-18 06:18:38.058109
9bf18238-9831-4498-972e-b2d4b2dde5b6	Whitefly	Bemisia tabaci	["Tomato", "Cotton", "Chilli", "Brinjal", "Cucumber"]	Small white-winged insects that feed on plant sap and are major vectors of viral diseases like Tomato Yellow Leaf Curl Virus.	["Yellowing leaves", "Sticky honeydew", "Sooty mold", "Wilting", "Virus symptoms (mosaic, curl)"]	2mm, white wings, found on leaf undersides	Sucking	Egg to adult in 3-4 weeks. Multiple overlapping generations.	["Yellow sticky traps", "Reflective mulch to repel", "Remove heavily infested leaves"]	["Neem oil 2%", "Verticillium lecanii fungal spray", "Soap solution"]	["Thiamethoxam 25 WG @ 0.3g/L", "Spiromesifen 22.9 SC @ 1ml/L"]	["Use virus-resistant varieties", "Install insect-proof nets in nursery", "Avoid planting near infected fields"]	severe	\N	2026-02-18 06:18:38.058115	2026-02-18 06:18:38.058116
7024bdb6-40ac-4026-a106-5d4bf76b9d04	Stem Borer	Chilo partellus	["Rice", "Corn", "Sorghum", "Sugarcane"]	Caterpillar that bores into stems causing 'dead heart' in young plants and 'white ear' in flowering stage.	["Dead heart (central shoot dies)", "White ear (empty panicle)", "Bore holes in stem", "Frass (excreta) in stem"]	Caterpillar: pale yellow with dark stripes; Adult: straw-colored moth	Boring	Egg to adult in 35-45 days. 3-4 generations per year.	["Remove and destroy egg masses", "Light traps for adult moths", "Pheromone traps"]	["Trichogramma egg parasitoid release", "Bacillus thuringiensis (Bt) spray"]	["Chlorpyrifos 20 EC @ 2.5ml/L", "Carbofuran 3G granules in whorl"]	["Timely planting", "Balanced fertilization", "Destroy crop residues after harvest"]	severe	\N	2026-02-18 06:18:38.05812	2026-02-18 06:18:38.05812
52779e26-a9b2-4cc1-85fa-6db31cdeb423	Thrips	Thrips tabaci	["Onion", "Chilli", "Cotton", "Groundnut", "Tomato"]	Tiny slender insects that rasp leaf surfaces and suck cell contents, causing silvery streaks and transmitting viruses.	["Silvery streaks on leaves", "Leaf curl", "Distorted flowers", "Premature fruit drop", "Scarring on onion bulbs"]	1-2mm, slender, yellowish-brown to dark brown	Rasping-sucking	Egg to adult in 2-3 weeks. Multiple generations.	["Blue sticky traps", "Avoid water stress", "Reflective mulch"]	["Neem seed kernel extract 5%", "Spinosad 45 SC @ 0.3ml/L"]	["Fipronil 5 SC @ 1.5ml/L", "Imidacloprid 17.8 SL @ 0.5ml/L"]	["Avoid planting near infected fields", "Crop rotation", "Remove weeds"]	moderate	\N	2026-02-18 06:18:38.058125	2026-02-18 06:18:38.058125
29558718-d3eb-456d-b58d-53111b49d5cb	Mealybug	Phenacoccus solenopsis	["Cotton", "Tomato", "Brinjal", "Papaya", "Grapes"]	White waxy-coated insects that cluster on stems and leaf joints, sucking sap and excreting honeydew.	["White cottony masses on stems/joints", "Yellowing and wilting", "Sooty mold", "Stunted growth"]	3-5mm, oval, covered in white waxy powder	Sucking	Egg to adult in 30-40 days. Spread by ants, wind, and farm equipment.	["Control ants (which protect mealybugs)", "Prune heavily infested parts", "Avoid excess nitrogen"]	["Neem oil 2%", "Beauveria bassiana spray", "Release Cryptolaemus beetles"]	["Profenofos 50 EC @ 2ml/L", "Buprofezin 25 SC @ 1ml/L"]	["Use certified pest-free planting material", "Quarantine new plants", "Regular field monitoring"]	moderate	\N	2026-02-18 06:18:38.058129	2026-02-18 06:18:38.058129
4975041b-d913-4b22-99e3-e6f712fb049b	Red Spider Mite	Tetranychus urticae	["Tomato", "Brinjal", "Cucumber", "Beans", "Cotton"]	Tiny mites that feed on leaf undersides, causing bronzing and webbing. Severe in hot dry conditions.	["Tiny yellow/white dots on leaves", "Bronze or rusty discoloration", "Fine webbing on undersides", "Leaf drop"]	0.5mm, oval, red/orange/green, barely visible to naked eye	Piercing-sucking	Egg to adult in 7-10 days in hot weather. Rapid population buildup.	["Maintain adequate soil moisture", "Avoid dusty conditions", "Spray water on undersides"]	["Neem oil 2%", "Sulphur 80 WP @ 2g/L", "Predatory mite release"]	["Abamectin 1.8 EC @ 0.5ml/L", "Spiromesifen 22.9 SC @ 1ml/L"]	["Avoid water stress", "Avoid broad-spectrum insecticides that kill natural enemies", "Intercrop with repellent plants"]	moderate	\N	2026-02-18 06:18:38.058133	2026-02-18 06:18:38.058134
4c816211-8b37-47db-89d8-58ef48ac3fde	American Bollworm	Helicoverpa armigera	["Cotton", "Tomato", "Chickpea", "Sorghum", "Maize"]	Major polyphagous pest. Caterpillar bores into bolls, fruits, and pods causing severe yield loss.	["Circular holes in fruits/bolls", "Frass at entry point", "Premature fruit drop", "Damaged seeds in pods"]	Caterpillar: green/brown with pale stripes; Adult: yellowish-brown moth	Boring	Egg to adult in 30-35 days. 5-6 generations per year.	["Pheromone traps (5/acre)", "Light traps", "Hand-pick egg masses"]	["Bacillus thuringiensis (Bt) spray @ 2g/L", "Nuclear Polyhedrosis Virus (NPV) @ 250 LE/ha"]	["Emamectin benzoate 5 SG @ 0.4g/L", "Chlorantraniliprole 18.5 SC @ 0.3ml/L"]	["Use Bt cotton varieties", "Avoid late planting", "Destroy crop residues", "Intercrop with marigold"]	severe	\N	2026-02-18 06:18:38.058138	2026-02-18 06:18:38.058138
265ff47e-ac31-4169-8e9c-151340565f53	Leaf Miner	Liriomyza trifolii	["Tomato", "Potato", "Beans", "Pea", "Celery"]	Larvae tunnel between leaf surfaces creating visible winding mines, reducing photosynthesis.	["Winding white/grey trails (mines) on leaves", "Blotchy patches", "Premature leaf drop", "Reduced photosynthesis"]	Adult: tiny black-yellow fly (2mm); Larva: pale yellow maggot inside leaf	Mining	Egg to adult in 2-3 weeks. Multiple overlapping generations.	["Yellow sticky traps", "Remove and destroy mined leaves", "Avoid broad-spectrum pesticides"]	["Neem oil 2%", "Spinosad 45 SC @ 0.3ml/L", "Release Diglyphus parasitoids"]	["Abamectin 1.8 EC @ 0.5ml/L", "Cyromazine 75 WP @ 0.6g/L"]	["Use fine mesh nets in nursery", "Crop rotation", "Remove crop debris"]	mild	\N	2026-02-18 06:18:38.058142	2026-02-18 06:18:38.058143
\.


--
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.post_likes (id, post_id, user_id, created_at) FROM stdin;
3d017645-a20b-4982-9b5f-0e9fc8b870c0	4f490e54-8363-403b-932c-a3ab29abf077	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	2026-02-04 05:50:33.939946
5c8fd9af-3746-40a2-8740-b9cc9ae3038c	6311f7cd-1c0c-425b-8eea-bda214ed8c67	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	2026-02-07 14:46:01.80567
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.questions (id, farmer_id, media_path, question_text, diagnosis_id, status, created_at, updated_at) FROM stdin;
1a825cd9-fbb3-4027-9a8b-59484183d505	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	\N	My tomato plants have dark spots on the leaves with yellow rings around them. What disease is this and how do I treat it?	\N	RESOLVED	2026-01-26 14:23:14.723453	2026-01-31 14:23:14.724138
d7e666de-3e89-4922-b95b-59a9802c318b	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	\N	The leaves on my potato plants are turning brown and wilting rapidly. Is this late blight? What should I do immediately?	\N	OPEN	2026-01-29 14:23:14.72348	2026-01-31 14:23:14.724143
8b208d5c-7eb9-4c23-b86c-6fb49c939d7f	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	\N	What is the best organic treatment for powdery mildew on my wheat crop?	\N	OPEN	2026-01-31 02:23:14.723489	2026-01-31 14:23:14.724147
aeac55ab-054c-44f2-8602-2b596bce7c89	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/questions/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260204_061224_e2d8abdc.png	help me with this	\N	OPEN	2026-02-04 06:12:24.669125	2026-02-04 06:12:24.669129
6137213b-d172-44c1-8ff9-4ee0cccb4685	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/images/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260204_061657_b14ad69e.png	I have a problem with my crop. Diagnosis suggests it's Viral Infection. Can you help with treatment?	717eacd4-0c68-412f-94f2-60373151a7f2	OPEN	2026-02-04 06:29:25.974478	2026-02-04 06:29:25.974481
e6d10075-d8bc-44f3-9325-398538e30c85	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	\N	hello , help me	\N	RESOLVED	2026-02-04 05:59:28.733985	2026-02-04 06:44:53.728511
37c7e1ad-40c7-4ade-a92c-6419206f728e	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	uploads/questions/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260204_060630_c24a406a.png	hi , help me diagnois it	\N	RESOLVED	2026-02-04 06:06:30.294592	2026-02-04 06:47:51.289252
f2759a4e-2c86-44cc-bd20-c1acdfe283a2	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	\N	I have a problem with my crop. Diagnosis suggests it's Deficiency. Can you help with treatment?	\N	RESOLVED	2026-02-09 09:04:50.200929	2026-02-09 09:06:51.066556
4594e58c-6dda-4525-9f9e-fca47f2be6cb	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	/uploads/questions/53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed_20260209_092058_72b3ca0e.jpeg	I have a problem with my crop. Diagnosis suggests it's Healthy. Can you help with treatment?	\N	OPEN	2026-02-09 09:20:58.590175	2026-02-09 09:20:58.590177
4162fc99-4269-4e92-bcab-d0f45fad5191	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	\N	I have a problem with my crop. Diagnosis suggests it's Healthy. Can you help with treatment?	\N	OPEN	2026-02-09 16:05:53.712262	2026-02-09 16:05:53.712266
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.system_logs (id, level, message, source, user_id, log_metadata, created_at) FROM stdin;
150ffcaf-ac9d-4197-8d3a-fa226689829a	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 331.56, "client_ip": "127.0.0.1"}	2026-02-04 06:32:25.589085
7b9bc09d-dc7b-42fc-87c8-932cc95b60e6	INFO	POST /community/posts - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 22.36, "client_ip": "127.0.0.1"}	2026-02-04 06:33:45.143058
9ad23436-2b19-457a-8aa6-4b070d8fd237	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 362.31, "client_ip": "127.0.0.1"}	2026-02-04 06:44:34.665391
0ea9a231-b92e-4db2-9154-11dfe0b4a8be	INFO	POST /expert/answer - 201	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 19.92, "client_ip": "127.0.0.1"}	2026-02-04 06:44:53.742878
09ca6d35-e808-47e7-8c45-6953c2e5f85d	INFO	POST /expert/answer - 201	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 38.86, "client_ip": "127.0.0.1"}	2026-02-04 06:47:51.30176
de386680-8610-465e-a362-3f92ad7d7eb9	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 661.0, "client_ip": "127.0.0.1"}	2026-02-04 08:28:32.900061
9c1b3fa9-d00e-494a-9e6f-e716515fc771	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 302.43, "client_ip": "127.0.0.1"}	2026-02-04 08:29:29.75695
6599a8e3-65f6-4aa9-ad8e-9f9bd23da682	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 276.27, "client_ip": "127.0.0.1"}	2026-02-04 08:31:05.343384
4d55d6bf-cc1d-452f-8bd7-24ccc328d9a3	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 371.4, "client_ip": "127.0.0.1"}	2026-02-04 08:32:21.595026
d36b0a8a-6bce-45b7-a468-98560a3de287	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 20.49, "client_ip": "127.0.0.1"}	2026-02-04 08:37:38.925536
f79d4802-dbab-4d96-aff7-8e617424d345	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.73, "client_ip": "127.0.0.1"}	2026-02-04 08:37:38.945153
6762ef0b-4608-4de1-b7f6-bd0e2814a521	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 2.79, "client_ip": "127.0.0.1"}	2026-02-04 08:37:38.978632
209854f3-bee4-4746-92c5-9ce6c1d35928	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 0.47, "client_ip": "127.0.0.1"}	2026-02-04 08:37:39.012045
911c7527-f36c-4106-a81c-97e5e43208f1	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 4.41, "client_ip": "127.0.0.1"}	2026-02-04 08:37:39.096641
52506297-ec0f-4bc5-b8cc-1efc60e80e67	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.84, "client_ip": "127.0.0.1"}	2026-02-04 08:37:39.104309
a7452e13-c0b2-4ea5-8342-8c4ebcd7ea0f	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 308.07, "client_ip": "127.0.0.1"}	2026-02-04 08:37:48.66821
9d10b586-d0dc-4b95-8530-a021a633bdbb	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 338.59, "client_ip": "127.0.0.1"}	2026-02-04 11:48:11.388931
847297af-ebba-4805-932d-e4cbdbf5d82f	WARNING	POST /auth/login - 422	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 422, "duration_ms": 18.46, "client_ip": "127.0.0.1"}	2026-02-04 11:59:47.5965
2ce3f9df-49a0-4366-9224-85dd0ce7c1ef	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 303.9, "client_ip": "127.0.0.1"}	2026-02-04 11:59:55.910975
8dacf678-50c3-4c46-9fc9-5ba19041b2d1	INFO	POST /questions/e6d10075-d8bc-44f3-9325-398538e30c85/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/e6d10075-d8bc-44f3-9325-398538e30c85/rate", "status_code": 200, "duration_ms": 10.99, "client_ip": "127.0.0.1"}	2026-02-04 12:00:06.573236
f47dde7d-2c00-43e4-91a5-d482aeffc755	INFO	POST /questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate", "status_code": 200, "duration_ms": 6.27, "client_ip": "127.0.0.1"}	2026-02-04 12:00:10.856749
9bb84a96-5d4d-4f5d-9b07-980d3c4e580f	INFO	POST /diagnosis/1948a1cf-429d-4be4-b79f-0df8970ba6ec/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/1948a1cf-429d-4be4-b79f-0df8970ba6ec/rate", "status_code": 200, "duration_ms": 26.41, "client_ip": "127.0.0.1"}	2026-02-04 12:00:19.456939
42be6115-33fe-47eb-aaab-0180b89dd446	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 382.48, "client_ip": "127.0.0.1"}	2026-02-06 05:19:49.931188
43732b9f-6c48-476e-8506-999b5e43edba	INFO	POST /questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate", "status_code": 200, "duration_ms": 16.15, "client_ip": "127.0.0.1"}	2026-02-06 05:23:42.23438
c6e766f7-e622-4e8a-b9ac-c475042e6111	INFO	POST /questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate", "status_code": 200, "duration_ms": 57.64, "client_ip": "127.0.0.1"}	2026-02-06 05:30:24.508599
2bc6af00-1aac-4d17-b1bd-d53702bc3f5d	INFO	POST /questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/1a825cd9-fbb3-4027-9a8b-59484183d505/rate", "status_code": 200, "duration_ms": 11.54, "client_ip": "127.0.0.1"}	2026-02-06 05:32:44.364806
816506fb-7959-42a3-bd8a-bddd05f4eb24	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 55.17, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.136612
5d599764-103b-481c-9993-ec6e2323d50b	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.7, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.174588
fd0f652b-4d61-416a-a616-f53f27c174e0	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 3.63, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.203102
9908262c-c622-478f-9506-bbb919730dc9	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 0.43, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.233082
ee618753-45af-4e92-8f73-074fb0f3604b	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 5.81, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.267496
43c88140-cac2-483d-9227-f6edd1cee601	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.49, "client_ip": "127.0.0.1"}	2026-02-06 06:10:43.272511
64658d19-c33e-430e-847c-3487a5492fd4	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 329.47, "client_ip": "127.0.0.1"}	2026-02-06 06:10:50.207495
213dd869-85e0-4ba5-920f-b3ea35716192	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 378.99, "client_ip": "127.0.0.1"}	2026-02-07 14:02:30.394927
dc21bc68-8cb8-49e8-94b4-570b830c8251	INFO	POST /community/posts - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 23.12, "client_ip": "127.0.0.1"}	2026-02-07 14:11:16.395376
c1953ad8-5fba-40f4-9fda-853b9b31a3bb	WARNING	POST /community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments - 401	api	\N	{"method": "POST", "path": "/community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments", "status_code": 401, "duration_ms": 23.76, "client_ip": "127.0.0.1"}	2026-02-07 14:32:47.062838
7c9a2502-ecc9-4a37-903e-c4c8a400a3fe	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 56.71, "client_ip": "127.0.0.1"}	2026-02-07 14:32:47.160749
de1cd7b7-7361-4d4f-b2d2-b6c65eb4372f	INFO	POST /community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments", "status_code": 201, "duration_ms": 34.18, "client_ip": "127.0.0.1"}	2026-02-07 14:32:47.216731
309dd5db-e93a-4990-ae8d-e9eb2565a51c	WARNING	GET /community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments - 405	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts/efa163c4-4982-4e89-afb1-e55e7f31f33b/comments", "status_code": 405, "duration_ms": 10.3, "client_ip": "127.0.0.1"}	2026-02-07 14:38:49.334039
05d4aeb4-ba15-431f-94fb-0f13c58c0f36	WARNING	GET /community/posts/4f490e54-8363-403b-932c-a3ab29abf077/comments - 405	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts/4f490e54-8363-403b-932c-a3ab29abf077/comments", "status_code": 405, "duration_ms": 0.45, "client_ip": "127.0.0.1"}	2026-02-07 14:38:51.642762
8987788e-5bfe-4ac1-afcb-b3e2b2de68f3	INFO	POST /community/posts/with-image - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/community/posts/with-image", "status_code": 201, "duration_ms": 100.97, "client_ip": "127.0.0.1"}	2026-02-07 14:45:58.204353
d3434462-8f20-430f-8bcb-136cbf5bdbdd	INFO	POST /community/posts/6311f7cd-1c0c-425b-8eea-bda214ed8c67/like - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/community/posts/6311f7cd-1c0c-425b-8eea-bda214ed8c67/like", "status_code": 200, "duration_ms": 11.17, "client_ip": "127.0.0.1"}	2026-02-07 14:46:01.810508
b4692e77-8e90-45c1-b594-e741da72899c	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 26.41, "client_ip": "127.0.0.1"}	2026-02-07 14:59:15.924102
2f40f552-3eca-4dca-92e1-1af2eb8de820	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 6.21, "client_ip": "127.0.0.1"}	2026-02-07 14:59:16.074723
3919f828-8723-4e7d-a770-aac736b5d07e	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.02, "client_ip": "127.0.0.1"}	2026-02-07 14:59:16.098922
f7d3adc4-9429-455d-82de-c27f566a3323	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 1.96, "client_ip": "127.0.0.1"}	2026-02-07 14:59:16.038283
f3791929-a8ed-40c1-887b-eea5c938b28e	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 2.95, "client_ip": "127.0.0.1"}	2026-02-07 14:59:16.123296
d7bf7d7c-3e7c-45d4-88a8-f5bdd169131c	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.37, "client_ip": "127.0.0.1"}	2026-02-07 14:59:16.126849
a6f858e9-b5bc-4567-9bea-44499d4302b1	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 283.82, "client_ip": "127.0.0.1"}	2026-02-07 14:59:23.054424
c1d784f4-bd79-4a44-a374-dd5a71bdbf9f	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 365.24, "client_ip": "127.0.0.1"}	2026-02-08 07:11:37.51591
86a74a8d-a54a-4d6f-bbd9-427031e5d2ce	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 262.96, "client_ip": "127.0.0.1"}	2026-02-08 07:14:15.255271
f574537b-fde5-461d-b436-75078c979927	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 256.07, "client_ip": "127.0.0.1"}	2026-02-08 07:15:13.965961
ade5f8f6-8d54-41ff-8e07-84ced2f28b5a	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 397.99, "client_ip": "127.0.0.1"}	2026-02-08 07:21:13.179647
adbb7063-9724-44f8-bc11-e92ef5ba7ff1	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 106.77, "client_ip": "127.0.0.1"}	2026-02-08 07:21:26.143985
05a68b4c-e71f-400a-a27a-a1f965d3ef1c	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 31.29, "client_ip": "127.0.0.1"}	2026-02-08 07:21:46.887189
b50a839a-6497-484f-a2ef-0b571d1fea86	WARNING	GET /agronomy/admin/rules - 401	api	\N	{"method": "GET", "path": "/agronomy/admin/rules", "status_code": 401, "duration_ms": 3.21, "client_ip": "127.0.0.1"}	2026-02-08 07:38:01.201862
c0fd19fd-a932-400f-9834-1dd3c53b226a	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 57.82, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.065561
f36c6382-b190-4087-8279-660b48851746	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.63, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.118153
64aebf8a-407b-49a6-bac0-5a9c7541c6fd	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 2.04, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.148553
44bd0f67-3d70-4bf6-a47f-b059bc30dd15	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 5.37, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.196721
48a5fffe-f73c-4ce9-a2db-57a8e864403d	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 2.97, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.226668
b5704415-0b3e-49c8-9cef-7e76b386560c	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.46, "client_ip": "127.0.0.1"}	2026-02-08 07:47:37.234545
57ec7ea3-3f7d-4b0e-ae61-851c259553fb	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 358.75, "client_ip": "127.0.0.1"}	2026-02-08 07:47:45.332404
ac883c03-9245-4459-97dd-d73c9310912e	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 1580.75, "client_ip": "127.0.0.1"}	2026-02-08 07:48:33.840702
34632e68-6517-49dc-96b2-03a90c50f2f5	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 293.23, "client_ip": "127.0.0.1"}	2026-02-08 08:19:06.232461
580af39f-eea7-4c09-8a10-1d2abfa216e3	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.21, "client_ip": "127.0.0.1"}	2026-02-08 08:19:06.686526
583100e3-f78f-4e96-bcd0-ac7e70a51471	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 257.47, "client_ip": "127.0.0.1"}	2026-02-08 08:19:07.380916
2e3b021a-3a80-4a63-98e6-91eb2e8099cc	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 270.95, "client_ip": "127.0.0.1"}	2026-02-08 08:19:08.092652
40b721ac-b6f9-4c48-9db5-6c4319f1188a	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 3.57, "client_ip": "127.0.0.1"}	2026-02-08 08:19:08.237539
6e3ac400-ef3c-47e7-8e25-8d1b48aa04e2	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.64, "client_ip": "127.0.0.1"}	2026-02-08 08:19:08.36736
74cbbce4-a9bd-4ab5-b9c6-94e11ecb2238	INFO	POST /community/posts - 201	api	95e124b8-4df4-48cc-b1d8-060acc8763d6	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 12.13, "client_ip": "127.0.0.1"}	2026-02-08 08:19:09.856382
cf36fbb8-df8d-4691-900b-0b5188252c5a	WARNING	POST /community/posts - 422	api	ed991a4a-69c7-4eff-a75d-44c8ec185703	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.54, "client_ip": "127.0.0.1"}	2026-02-08 08:19:10.281545
5aab92e9-5e66-48ac-b9c6-5acd809c86e3	INFO	POST /community/posts - 201	api	e5fd6098-f437-4d92-aff9-19babd002cdc	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 7.81, "client_ip": "127.0.0.1"}	2026-02-08 08:19:10.834518
45c3cb6d-881d-4308-8391-5a5441dddb73	INFO	POST /community/posts - 201	api	1002242c-c48e-4beb-a45d-fc707f0e1ba1	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 10.36, "client_ip": "127.0.0.1"}	2026-02-08 08:19:11.302132
23255cf5-5814-4512-b8db-2e9ba6f8dabd	INFO	POST /community/posts/8c09b16e-8f88-4266-9daf-679e51ef62be/like - 200	api	1002242c-c48e-4beb-a45d-fc707f0e1ba1	{"method": "POST", "path": "/community/posts/8c09b16e-8f88-4266-9daf-679e51ef62be/like", "status_code": 200, "duration_ms": 11.03, "client_ip": "127.0.0.1"}	2026-02-08 08:19:11.316514
0e213a6a-7c60-4ebc-b13f-068cbff90546	INFO	POST /community/posts - 201	api	1324e4c8-5b41-4f37-a2ea-88265ff3443a	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.56, "client_ip": "127.0.0.1"}	2026-02-08 08:19:11.758862
fda083b3-121a-4520-a7df-c8aac9c7a981	INFO	POST /community/posts/843c21c9-2487-4373-926a-2e125f1aab10/comments - 201	api	1324e4c8-5b41-4f37-a2ea-88265ff3443a	{"method": "POST", "path": "/community/posts/843c21c9-2487-4373-926a-2e125f1aab10/comments", "status_code": 201, "duration_ms": 7.68, "client_ip": "127.0.0.1"}	2026-02-08 08:19:11.768776
ef9e9c9e-4f77-46f4-a770-e83cbc788765	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.4, "client_ip": "127.0.0.1"}	2026-02-08 08:19:12.756057
9e62dae3-679d-44f7-bfdc-82672e0cd398	INFO	POST /farm/crops - 201	api	cf52576c-373e-466b-ad6a-1ba35c5596f8	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 19.46, "client_ip": "127.0.0.1"}	2026-02-08 08:19:15.735805
16d13b1f-890b-4e7e-8c94-6430de61e43f	INFO	POST /farm/tasks - 201	api	9503a561-18ac-462e-a62c-8b0f1c73aec5	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.25, "client_ip": "127.0.0.1"}	2026-02-08 08:19:16.520125
f4e820ef-9711-4e74-b558-1629b3e2b034	INFO	POST /farm/tasks - 201	api	6c1100ed-8ff7-4da8-99b0-a95a681b96c5	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 23.4, "client_ip": "127.0.0.1"}	2026-02-08 08:19:16.919192
5e395022-8dbf-48ba-8ae4-9ba96862b33a	INFO	PUT /farm/tasks/896135f5-8897-4a7b-80cd-1ec3cc301914/complete - 200	api	6c1100ed-8ff7-4da8-99b0-a95a681b96c5	{"method": "PUT", "path": "/farm/tasks/896135f5-8897-4a7b-80cd-1ec3cc301914/complete", "status_code": 200, "duration_ms": 4.26, "client_ip": "127.0.0.1"}	2026-02-08 08:19:16.925558
b1f0d187-a1da-4230-b676-918ff27d75a0	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.59, "client_ip": "127.0.0.1"}	2026-02-08 08:19:18.255899
0d9a034c-d3db-49fc-bf6e-f5c6df0fe099	INFO	POST /questions - 201	api	9d9e804b-cf95-49c1-91bc-975571bec263	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.76, "client_ip": "127.0.0.1"}	2026-02-08 08:19:18.630299
d325622c-f0e8-4cc1-ba79-f436537844f9	WARNING	POST /questions - 422	api	e97be520-1c45-4540-b300-b3745a488c4d	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 2.01, "client_ip": "127.0.0.1"}	2026-02-08 08:19:19.054664
fc97d371-6e9b-4e80-9d80-7ea3227bab10	INFO	POST /questions - 201	api	a92dd9dc-903a-4016-9a30-77e39b321a52	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.8, "client_ip": "127.0.0.1"}	2026-02-08 08:19:19.87863
f6c3ec55-3bf0-49a9-9960-a2c94abb1feb	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.67, "client_ip": "127.0.0.1"}	2026-02-08 08:19:20.050735
ddfd21be-ed10-44d1-8e5d-68bd4d4aa768	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	3bd439eb-c70d-4a7b-80b1-2828388d6d94	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.38, "client_ip": "127.0.0.1"}	2026-02-08 08:19:20.465665
946762ba-02af-4f4c-80a1-4c17ade90249	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 372.93, "client_ip": "127.0.0.1"}	2026-02-09 04:45:50.718774
e2957077-c509-4447-a18b-cadbbe068302	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 9.91, "client_ip": "127.0.0.1"}	2026-02-09 04:47:08.3284
82719ed6-f05f-49c7-bd0e-30b8cb414920	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 2.81, "client_ip": "127.0.0.1"}	2026-02-09 04:47:29.486316
17a992fe-1636-4e4b-8c5c-f0450b6ead8f	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 1.39, "client_ip": "127.0.0.1"}	2026-02-09 04:47:35.360942
50e56fac-2ac3-4d33-bb8e-287ff92fffb1	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 22.17, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.439841
6b0bd75f-42d6-4e88-b616-a950791d76b9	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.66, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.524537
f0f1498d-f647-4821-a5c5-d447f2890c76	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 3.76, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.557123
7fed5d5e-eecc-45d1-b5b2-270ff2585045	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.17, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.586065
02804e73-618a-4f0f-9d27-312a3f4e00ea	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 5.68, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.683266
2b63c7b4-57a0-4b70-84b9-de401f1a7b3a	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.38, "client_ip": "127.0.0.1"}	2026-02-09 04:48:07.698161
0cec030f-d44e-4ddd-8f9e-c9f95196b282	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 307.09, "client_ip": "127.0.0.1"}	2026-02-09 04:48:14.231282
271b117e-1016-4983-9e7a-0ca2dcdc9982	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 47.35, "client_ip": "127.0.0.1"}	2026-02-09 09:03:13.435656
2787d068-383f-42e3-b47e-d6e3b6b0f293	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 303.28, "client_ip": "127.0.0.1"}	2026-02-09 09:03:23.504354
2779c21c-c9ff-4973-9888-1c80d6f259e8	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 3.88, "client_ip": "127.0.0.1"}	2026-02-09 09:04:09.8851
cf234105-1c83-448e-ad1d-0d30460a029b	WARNING	POST /diagnosis/null/rate - 400	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/null/rate", "status_code": 400, "duration_ms": 48.9, "client_ip": "127.0.0.1"}	2026-02-09 09:04:37.406981
8f57e86a-31b1-467c-88c7-288d2c2bba17	INFO	POST /questions - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 18.98, "client_ip": "127.0.0.1"}	2026-02-09 09:04:50.215465
4584a049-2542-40b7-91d9-dc270ce2e819	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 258.53, "client_ip": "127.0.0.1"}	2026-02-09 09:06:30.501875
ffe4fb8c-907b-460c-98ee-dbfdb5b402cb	INFO	POST /expert/answer - 201	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 14.5, "client_ip": "127.0.0.1"}	2026-02-09 09:06:51.077335
5965483d-805b-4705-833c-e7dccdf3e496	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 22.59, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.673511
a67ae9b0-6d4c-45ce-a4dd-384db3d3921a	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.65, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.791491
26c15159-bf06-4c2a-9dfd-54e2a35c58a9	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 2.42, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.830117
bbf0576f-e481-4d2f-bc49-314a492e8d50	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 0.33, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.851571
dfb32776-1351-4876-9682-b1f3a6740d67	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 3.58, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.95027
e6d29bd7-c67f-47b8-a48b-c63a1c6b40fc	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.37, "client_ip": "127.0.0.1"}	2026-02-09 09:07:15.95668
61d3d561-a0c1-4b80-a928-67b24f1bc0f9	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 313.75, "client_ip": "127.0.0.1"}	2026-02-09 09:07:56.969513
46f9142c-735b-4c55-99c6-588883fbed30	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 313.9, "client_ip": "127.0.0.1"}	2026-02-09 09:10:09.056268
eddcdf33-f64a-4478-a5b1-774131cce689	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 2.17, "client_ip": "127.0.0.1"}	2026-02-09 09:10:48.79255
e215cae7-846e-4caa-91f3-a4090f55ff7c	WARNING	POST /agronomy/validate-diagnosis - 422	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "status_code": 422, "duration_ms": 22.19, "client_ip": "127.0.0.1"}	2026-02-09 09:11:09.180057
d6ead354-3541-4b19-9f2a-f554a9d96a63	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 4.81, "client_ip": "127.0.0.1"}	2026-02-09 09:14:54.602953
6162b753-7d29-40a2-8761-c8dd662c830f	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "error": "(sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input for query argument $1: 'healthy_lemon' (invalid UUID 'healthy_lemon': length must be between 32..36 characters, got 13)\\n[SQL: SELECT agronomy_diagnostic_rules.id, agronomy_diagnostic_rules.disease_id, agronomy_diagnostic_rules.rule_name, agronomy_diagnostic_rules.description, agronomy_diagnostic_rules.conditions, agronomy_diagnostic_rules.impact, agronomy_diagnostic_rules.priority, agronomy_diagnostic_rules.is_active, agronomy_diagnostic_rules.created_at, agronomy_diagnostic_rules.updated_at \\nFROM agronomy_diagnostic_rules \\nWHERE agronomy_diagnostic_rules.disease_id = $1::UUID AND agronomy_diagnostic_rules.is_active]\\n[parameters: ('healthy_lemon',)]\\n(Background on this error at: https://sqlalche.me/e/20/dbapi)"}	2026-02-09 09:15:06.031956
c871dd41-5f30-4ef6-b585-8068be176f32	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "error": "(sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input for query argument $1: 'healthy_lemon' (invalid UUID 'healthy_lemon': length must be between 32..36 characters, got 13)\\n[SQL: SELECT agronomy_diagnostic_rules.id, agronomy_diagnostic_rules.disease_id, agronomy_diagnostic_rules.rule_name, agronomy_diagnostic_rules.description, agronomy_diagnostic_rules.conditions, agronomy_diagnostic_rules.impact, agronomy_diagnostic_rules.priority, agronomy_diagnostic_rules.is_active, agronomy_diagnostic_rules.created_at, agronomy_diagnostic_rules.updated_at \\nFROM agronomy_diagnostic_rules \\nWHERE agronomy_diagnostic_rules.disease_id = $1::UUID AND agronomy_diagnostic_rules.is_active]\\n[parameters: ('healthy_lemon',)]\\n(Background on this error at: https://sqlalche.me/e/20/dbapi)"}	2026-02-09 09:15:16.076608
53c976ef-ef27-4a62-9728-4c56755be206	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "error": "(sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.DataError'>: invalid input for query argument $1: 'healthy_lemon' (invalid UUID 'healthy_lemon': length must be between 32..36 characters, got 13)\\n[SQL: SELECT agronomy_diagnostic_rules.id, agronomy_diagnostic_rules.disease_id, agronomy_diagnostic_rules.rule_name, agronomy_diagnostic_rules.description, agronomy_diagnostic_rules.conditions, agronomy_diagnostic_rules.impact, agronomy_diagnostic_rules.priority, agronomy_diagnostic_rules.is_active, agronomy_diagnostic_rules.created_at, agronomy_diagnostic_rules.updated_at \\nFROM agronomy_diagnostic_rules \\nWHERE agronomy_diagnostic_rules.disease_id = $1::UUID AND agronomy_diagnostic_rules.is_active]\\n[parameters: ('healthy_lemon',)]\\n(Background on this error at: https://sqlalche.me/e/20/dbapi)"}	2026-02-09 09:15:21.017538
31d9e398-f88a-4d79-a12d-c32533efb59c	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 3.69, "client_ip": "127.0.0.1"}	2026-02-09 09:19:21.920351
906ab9eb-66ff-45a1-996d-b3f205e34ff7	INFO	POST /agronomy/validate-diagnosis - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "status_code": 200, "duration_ms": 29.7, "client_ip": "127.0.0.1"}	2026-02-09 09:19:31.01262
0d2a1fcf-631a-4c98-9b66-124c17b39248	INFO	POST /agronomy/validate-diagnosis - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/agronomy/validate-diagnosis", "status_code": 200, "duration_ms": 12.75, "client_ip": "127.0.0.1"}	2026-02-09 09:19:35.765527
a1b6f615-166f-4b47-a43a-9b7700c4976b	INFO	POST /questions/with-file - 201	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/with-file", "status_code": 201, "duration_ms": 25.1, "client_ip": "127.0.0.1"}	2026-02-09 09:20:58.600208
49ef64d2-9bca-4386-9e91-9c90ec24b7cd	INFO	POST /questions/f2759a4e-2c86-44cc-bd20-c1acdfe283a2/rate - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/questions/f2759a4e-2c86-44cc-bd20-c1acdfe283a2/rate", "status_code": 200, "duration_ms": 10.92, "client_ip": "127.0.0.1"}	2026-02-09 09:21:08.15374
dcd6d35f-f50d-4167-8e3d-030cc6d5c1c0	WARNING	GET /agronomy/admin/rules - 401	api	\N	{"method": "GET", "path": "/agronomy/admin/rules", "status_code": 401, "duration_ms": 26.77, "client_ip": "127.0.0.1"}	2026-02-09 12:55:52.924116
0636ec9e-7448-40db-ba4a-4b4b41b452b7	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 437.6, "client_ip": "127.0.0.1"}	2026-02-09 12:56:01.196489
1f894a94-efa4-49e6-b254-3b02da874be6	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 268.31, "client_ip": "127.0.0.1"}	2026-02-09 12:56:28.621473
2a4a6800-6ea2-4a0a-b98a-8ec1cde0bcd6	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 268.89, "client_ip": "127.0.0.1"}	2026-02-09 12:56:50.346917
d1f23ff5-9a8c-457b-9691-6d391a1100e3	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableE	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/knowledge-base", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableError'>: relation \\"knowledge_guides\\" does not exist\\n[SQL: SELECT count(knowledge_guides.id) AS count_1 \\nFROM knowledge_guides]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:56:52.681329
8bfeb6bf-14c3-4c19-9c99-29bd255c8b74	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 12:56:57.723786
62013fdd-1b82-4f59-ae70-a3bf9bd4a6a3	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 12:56:59.191673
df77fc61-c62c-4967-921f-d6909a07d34b	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 12:57:00.278207
d3cd2dfe-56e1-4016-875c-6ce0c14d7b2e	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:57:02.154379
eb6d5204-93e0-4b7f-8271-84bff7d0833d	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableE	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/knowledge-base", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableError'>: relation \\"knowledge_guides\\" does not exist\\n[SQL: SELECT count(knowledge_guides.id) AS count_1 \\nFROM knowledge_guides]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:57:09.698228
2e4c3b4d-fd45-4745-b235-a261036a0259	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 12:57:15.985075
3d363106-5e5f-4d00-882b-9f5cd90f8745	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableE	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/knowledge-base", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableError'>: relation \\"knowledge_guides\\" does not exist\\n[SQL: SELECT count(knowledge_guides.id) AS count_1 \\nFROM knowledge_guides]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:57:44.749703
9f1201db-7365-49d7-8302-f3a38b9111a4	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:03.545725
630f61cb-623d-46ef-8388-564c047099fd	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:28.438644
3441b0c0-bf75-459a-87e9-7015b3460d23	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true AND community_posts.user_id = $1::UUID]\\n[parameters: (UUID('ad4863d1-3073-4606-8100-999fe3b3942e'),)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:29.296231
229860cd-e00f-4b7a-996b-3d7c43742dec	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:30.772595
763936ff-44f9-46cf-9b05-ae8ddfd2ca75	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true AND community_posts.user_id = $1::UUID]\\n[parameters: (UUID('ad4863d1-3073-4606-8100-999fe3b3942e'),)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:32.778934
fa470474-f41e-4b3e-9963-f2b7d6f26ebb	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:33.437607
9eae2026-fafe-4a1c-b4d7-d494a219247f	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true AND community_posts.user_id = $1::UUID]\\n[parameters: (UUID('ad4863d1-3073-4606-8100-999fe3b3942e'),)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:33.932237
47140b77-4fe1-4778-9fbc-96f2d83034b8	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.is_expert_post does not exist\\n[SQL: SELECT count(community_posts.id) AS count_1 \\nFROM community_posts \\nWHERE community_posts.is_expert_post = true]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:58:34.597809
966268ff-6ecf-44a5-9cf9-aa659bbd7eaf	WARNING	GET /agronomy/seasonal-patterns - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/seasonal-patterns", "status_code": 404, "duration_ms": 20.44, "client_ip": "127.0.0.1"}	2026-02-09 13:17:00.847259
97043f36-2f1c-4204-8c1b-d2b5cf80bdd5	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 12:59:37.562254
12cb3450-a7d2-4caa-aa41-32dd3fd6bc08	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id ORDER BY community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:59:39.821448
4eb5c7fc-c53b-4afa-94e7-68cc0c500716	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id \\nWHERE community_posts.user_id = $1::UUID ORDER BY community_posts.created_at DESC \\n LIMIT $2::INTEGER OFFSET $3::INTEGER]\\n[parameters: (UUID('ad4863d1-3073-4606-8100-999fe3b3942e'), 20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:59:41.011698
df03522a-9f21-4d9a-88ef-d847a9d5a24a	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id ORDER BY community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 12:59:41.720927
856ce656-d6f6-487d-b43b-0e4e49de39e5	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id ORDER BY community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:00:00.890927
d14fd16e-007d-4334-9a07-d26b2710e522	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id \\nWHERE community_posts.user_id = $1::UUID ORDER BY community_posts.created_at DESC \\n LIMIT $2::INTEGER OFFSET $3::INTEGER]\\n[parameters: (UUID('ad4863d1-3073-4606-8100-999fe3b3942e'), 20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:00:03.406514
3a7ac484-4904-40b5-867a-c6c20ff5e5fe	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:23.347209
74704ec8-fb62-49ae-bf70-57f22bc5cdf6	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:23.796335
e919ef9b-734e-4c5a-bd18-cfcbeff02f6d	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id ORDER BY community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:00:04.960617
47234bcf-670c-4d43-8ca0-1b2f753ced85	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:00:07.997069
1faef5e4-b2c5-4592-9c58-f24356b9ae6c	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableE	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/knowledge-base", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableError'>: relation \\"knowledge_guides\\" does not exist\\n[SQL: SELECT count(knowledge_guides.id) AS count_1 \\nFROM knowledge_guides]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:00:09.87962
8cbbf2d6-2d6d-4512-bdd1-7d57946ed2d8	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/community-posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at, users.id AS id_1, users.email, users.password_hash, users.full_name, users.phone, users.role, users.status, users.is_verified, users.otp_code, users.otp_created_at, users.expertise_domain, users.qualification, users.experience_years, users.location, users.created_at AS created_at_1, users.updated_at AS updated_at_1 \\nFROM community_posts JOIN users ON community_posts.user_id = users.id ORDER BY community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:00:12.45914
151f7176-7bfc-4955-b302-cf68f1491c18	WARNING	GET /api/community/posts - 404	api	\N	{"method": "GET", "path": "/api/community/posts", "status_code": 404, "duration_ms": 2.32, "client_ip": "127.0.0.1"}	2026-02-09 13:00:42.691
730764f7-7652-4080-ad4f-a7c549aeb0c9	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 330.33, "client_ip": "127.0.0.1"}	2026-02-09 13:01:09.80501
d9b9ed2e-cd9a-4e99-ae86-99345969e6b9	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:01:12.282021
833c3cd8-91b7-46fe-8d03-1996dd021821	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:01:13.624415
aef4baac-ba74-426e-a2de-110331a1466a	WARNING	GET /api/farmer/community - 404	api	\N	{"method": "GET", "path": "/api/farmer/community", "status_code": 404, "duration_ms": 2.34, "client_ip": "127.0.0.1"}	2026-02-09 13:01:22.849246
de27b466-0898-44b2-859a-2cbf176092db	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:01:26.783961
6286305f-42e8-483e-b505-41d968a0be4e	WARNING	GET /agronomy/treatment-constraints - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/treatment-constraints", "status_code": 404, "duration_ms": 19.11, "client_ip": "127.0.0.1"}	2026-02-09 13:17:00.848952
329b3e55-6db5-405d-84bf-3eb58be1e03b	WARNING	GET /agronomy/treatment-constraints - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/treatment-constraints", "status_code": 404, "duration_ms": 9.42, "client_ip": "127.0.0.1"}	2026-02-09 13:17:10.424578
66bcaaf1-5d56-43b6-bac6-5415af0f89b5	WARNING	GET /agronomy/diagnostic-rules - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 404, "duration_ms": 6.86, "client_ip": "127.0.0.1"}	2026-02-09 13:17:10.422854
499119cf-63ea-43bc-b987-2512c0eb4415	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 411.28, "client_ip": "127.0.0.1"}	2026-02-10 07:16:15.107278
85ac1e86-ee00-4079-b249-68dd58945378	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:01:57.838426
830e6406-2805-4a84-9b6f-e0a8b65c24fc	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:02:28.323153
51b8ebf1-2e0b-4dd2-bd1e-0b6f015eb731	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:03:42.004132
389007d5-f3d8-4749-8b28-8e1966c6046d	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumn	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/community/posts", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedColumnError'>: column community_posts.category does not exist\\n[SQL: SELECT community_posts.id, community_posts.user_id, community_posts.title, community_posts.content, community_posts.image_path, community_posts.category, community_posts.is_expert_post, community_posts.likes_count, community_posts.comments_count, community_posts.is_pinned, community_posts.created_at, community_posts.updated_at \\nFROM community_posts ORDER BY community_posts.is_pinned DESC, community_posts.created_at DESC \\n LIMIT $1::INTEGER OFFSET $2::INTEGER]\\n[parameters: (20, 0)]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:03:42.625659
8a5d2e69-f20d-4160-9d29-204feee1e595	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 285.81, "client_ip": "127.0.0.1"}	2026-02-09 13:07:37.411323
4064e4f1-fff7-4bd8-be90-c7e8304adf4f	INFO	POST /community/posts - 201	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 31.7, "client_ip": "127.0.0.1"}	2026-02-09 13:08:18.490939
035922a9-ea96-4225-a44f-3a22bd1702b2	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:09:26.324049
2358ec00-b618-4dc4-bafc-9a32590bd384	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:09:27.323587
ead05c2c-9864-48f9-bca1-d29016f32074	CRITICAL	Unhandled Exception: (sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableE	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/knowledge-base", "error": "(sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError) <class 'asyncpg.exceptions.UndefinedTableError'>: relation \\"knowledge_guides\\" does not exist\\n[SQL: SELECT count(knowledge_guides.id) AS count_1 \\nFROM knowledge_guides]\\n(Background on this error at: https://sqlalche.me/e/20/f405)"}	2026-02-09 13:09:42.199197
e6405755-f211-4f63-a80f-66dd64bb4d6d	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:14:58.859046
c0d493d0-9d20-4326-a812-bf87dc2f7df3	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:00.182432
3b60ba90-0313-49a6-9733-b7ea58996d52	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:00.652922
c4695f7d-d930-49a5-b083-9cc11486f6e9	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:01.118755
5cd903f2-5583-49cf-80ef-0a7de7561615	CRITICAL	Unhandled Exception: cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/ba	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/expert/trending-diseases", "error": "cannot import name 'DiagnosisResult' from 'app.models.diagnosis' (/Users/akshayks/Desktop/SE_Proj/backend/app/models/diagnosis.py)"}	2026-02-09 13:15:22.087738
a55dd1fa-42d0-4b09-9ba6-5356f2a2d6ab	WARNING	GET /agronomy/diagnostic-rules - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 404, "duration_ms": 3.88, "client_ip": "127.0.0.1"}	2026-02-09 13:17:00.833815
de68ced0-df56-43bd-aeb3-a7bcac4d5c86	WARNING	GET /agronomy/seasonal-patterns - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/seasonal-patterns", "status_code": 404, "duration_ms": 10.11, "client_ip": "127.0.0.1"}	2026-02-09 13:17:10.425587
21dfb7e3-b1f4-4cf0-b75f-a867d5cc7e6b	WARNING	GET /agronomy/seasonal-patterns - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/seasonal-patterns", "status_code": 404, "duration_ms": 20.42, "client_ip": "127.0.0.1"}	2026-02-09 13:19:24.159284
8cede721-0a2e-4f30-b16a-eb97ce8a47b2	WARNING	GET /agronomy/diagnostic-rules - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 404, "duration_ms": 2.77, "client_ip": "127.0.0.1"}	2026-02-09 13:19:24.156301
002944c0-282d-48aa-8880-aaa12594ec22	WARNING	GET /admin/experts/pending - 401	api	\N	{"method": "GET", "path": "/admin/experts/pending", "status_code": 401, "duration_ms": 23.06, "client_ip": "127.0.0.1"}	2026-02-09 13:36:30.762863
1463ad59-9c13-412d-97c2-8d3ff0cbd3b9	WARNING	GET /agronomy/treatment-constraints - 401	api	\N	{"method": "GET", "path": "/agronomy/treatment-constraints", "status_code": 401, "duration_ms": 14.2, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.857969
58035947-68eb-40c4-ad43-3bc1b68084f5	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 15.82, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.957396
438c9398-856e-4e17-ac42-3893ee0b3c1f	INFO	POST /admin/experts/approve/038881eb-c8d2-4d51-aca1-da5fde9187b3 - 200	api	4890e59f-68de-4b9f-af85-7e3b126fe327	{"method": "POST", "path": "/admin/experts/approve/038881eb-c8d2-4d51-aca1-da5fde9187b3", "status_code": 200, "duration_ms": 3.02, "client_ip": "127.0.0.1"}	2026-02-09 17:04:41.741224
d49f88a0-5d09-4054-9c0b-2a0903960a57	WARNING	GET /admin/dashboard - 403	api	82d09e3b-e924-4b81-93e2-f349aea6c2b2	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.42, "client_ip": "127.0.0.1"}	2026-02-09 17:04:43.920516
5d18d711-c1f4-44f8-b782-c42022e60f0f	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 0.73, "client_ip": "127.0.0.1"}	2026-02-09 17:04:45.800357
8a3cbdf9-535f-4e9d-a143-93b66fb17129	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 400.4, "client_ip": "127.0.0.1"}	2026-02-09 17:04:46.305739
96b1799d-f44e-4b3c-b56e-1dfd8180a433	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.08, "client_ip": "127.0.0.1"}	2026-02-09 17:04:46.730911
d439b63e-efb3-4147-8281-344e29f7c095	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 246.25, "client_ip": "127.0.0.1"}	2026-02-09 17:04:47.40002
0d8af0de-a4c1-427b-9b50-be6d2cd46780	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 249.65, "client_ip": "127.0.0.1"}	2026-02-09 17:04:48.083961
36f56767-d275-4d60-a004-487c23ce7b90	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 5.49, "client_ip": "127.0.0.1"}	2026-02-09 17:04:48.265952
7363e1d1-e074-41f0-a683-328bb8cc9c81	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.62, "client_ip": "127.0.0.1"}	2026-02-09 17:04:48.398641
00cfd1c7-ba40-484f-98cd-19cd5e5d0220	INFO	POST /community/posts - 201	api	44eb5d52-8c3d-4b78-bbf7-604e4ed9988a	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 9.69, "client_ip": "127.0.0.1"}	2026-02-09 17:04:49.889797
00878f78-ef11-4828-a7f4-9fddd5137f02	WARNING	POST /community/posts - 422	api	2b960b55-6cba-4a1f-a9fb-fee0109e49e6	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 4.01, "client_ip": "127.0.0.1"}	2026-02-09 17:04:50.340339
93b33855-172e-4684-bb9d-e708d4a1bf40	INFO	POST /community/posts - 201	api	75cfcdb5-5516-4fc1-a142-adf0f86b73bb	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.03, "client_ip": "127.0.0.1"}	2026-02-09 17:04:50.791231
51c78dbd-5585-4315-8825-5d840a5a9f0e	INFO	POST /community/posts - 201	api	7a4208ee-a7e8-4487-886f-87d4b05aab5d	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.75, "client_ip": "127.0.0.1"}	2026-02-09 17:04:51.229113
5ddd7e43-9fbd-4e6c-8a81-2ca1595dd01e	INFO	POST /community/posts/08d12a2c-25f2-440c-9589-fd06091154bc/like - 200	api	7a4208ee-a7e8-4487-886f-87d4b05aab5d	{"method": "POST", "path": "/community/posts/08d12a2c-25f2-440c-9589-fd06091154bc/like", "status_code": 200, "duration_ms": 8.64, "client_ip": "127.0.0.1"}	2026-02-09 17:04:51.239838
cfab3d6b-9c6b-49b6-b6ac-28efa433ca16	INFO	POST /community/posts - 201	api	5fdaaba8-94b2-4d5d-b351-39acfd1fca7b	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 9.35, "client_ip": "127.0.0.1"}	2026-02-09 17:04:51.672909
65820b33-f8d6-44b2-a782-8b0cdf13711b	INFO	POST /community/posts/cd426793-33d4-410b-9286-03b0d060f267/comments - 201	api	5fdaaba8-94b2-4d5d-b351-39acfd1fca7b	{"method": "POST", "path": "/community/posts/cd426793-33d4-410b-9286-03b0d060f267/comments", "status_code": 201, "duration_ms": 9.24, "client_ip": "127.0.0.1"}	2026-02-09 17:04:51.68462
6a2ad8e4-594e-486c-b1be-9d6c0948153b	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.71, "client_ip": "127.0.0.1"}	2026-02-09 17:04:52.820144
451a4b36-fd62-496f-942e-9b871bc3bcaa	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 34.29, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.582605
f5e11da8-6050-46aa-a018-6874698e420f	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.8, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.620617
38552601-4055-471d-b9ff-dd511c3603eb	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 5.25, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.647628
e8efa4fc-3001-486b-8c4a-b63cab8feb10	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 0.69, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.693148
83531e48-f692-477d-b1cd-923698002313	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 1.11, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.764599
d4c39013-d099-48f5-8c0c-e1cf700e8878	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 336.21, "client_ip": "127.0.0.1"}	2026-02-10 07:30:30.268332
033b8a20-4a27-4665-b3fc-279b18b69f47	WARNING	GET /admin/experts/pending - 401	api	\N	{"method": "GET", "path": "/admin/experts/pending", "status_code": 401, "duration_ms": 1.87, "client_ip": "127.0.0.1"}	2026-02-09 13:36:30.803627
61a29343-3409-48d6-b883-1fda9158a98e	WARNING	GET /encyclopedia/crops - 401	api	\N	{"method": "GET", "path": "/encyclopedia/crops", "status_code": 401, "duration_ms": 2.78, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.861562
2905565c-64b9-4508-a3b2-3fedac3d69fc	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 18.15, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.956406
fc8b1f90-5b08-4ce4-a3c0-da60132de91e	INFO	POST /expert/answer - 201	api	3e1f1399-d0ab-4079-9c51-db49d5792358	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 11.84, "client_ip": "127.0.0.1"}	2026-02-09 17:04:58.803332
3f6997cc-14c8-454f-bff9-b9f9d7b471ef	INFO	POST /expert/answer - 201	api	12fc2c5b-ade5-4075-8df0-b2f8472ed246	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 22.27, "client_ip": "127.0.0.1"}	2026-02-09 17:05:00.176994
2c941a77-ef59-44e3-99b7-ac4d1348ef05	WARNING	POST /expert/answer - 409	api	12fc2c5b-ade5-4075-8df0-b2f8472ed246	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.99, "client_ip": "127.0.0.1"}	2026-02-09 17:05:00.184033
36b31ac7-f315-434f-89e9-c04256b484ab	WARNING	GET /expert/questions - 403	api	75898195-6b54-4d9e-ba39-0de4117be65b	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 2.07, "client_ip": "127.0.0.1"}	2026-02-09 17:05:00.667029
7b709860-7fc8-40ec-a3df-b1ebcf0b169b	INFO	PUT /expert/profile - 200	api	a3b44f01-2d07-4d9a-8629-4f95c0cf7e2d	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.09, "client_ip": "127.0.0.1"}	2026-02-09 17:05:01.699329
0c40fb37-97bc-481b-8684-84b0f0284ba7	INFO	POST /farm/crops - 201	api	d2b64078-45f1-4451-87a3-6b8ed153af69	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 23.47, "client_ip": "127.0.0.1"}	2026-02-09 17:05:03.005033
441c07ff-e25c-4bef-94cd-d5398afa8673	INFO	POST /farm/tasks - 201	api	56846b63-bd82-4f29-b7d0-8c36e96e84a6	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 26.25, "client_ip": "127.0.0.1"}	2026-02-09 17:05:04.160945
94c06e5b-c216-4f48-a945-298e01f3fe6c	INFO	POST /farm/tasks - 201	api	e2e517ef-b618-48cd-8c96-b851148da144	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 19.72, "client_ip": "127.0.0.1"}	2026-02-09 17:05:04.687999
5044ef66-eac4-4b5e-9b3a-02ee0591d8c3	INFO	PUT /farm/tasks/ddac1a52-fd3b-4e94-b3e1-9260ca52ffa5/complete - 200	api	e2e517ef-b618-48cd-8c96-b851148da144	{"method": "PUT", "path": "/farm/tasks/ddac1a52-fd3b-4e94-b3e1-9260ca52ffa5/complete", "status_code": 200, "duration_ms": 6.43, "client_ip": "127.0.0.1"}	2026-02-09 17:05:04.696876
1c99a361-92f1-4b94-a0f9-dc64fab50cf4	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.56, "client_ip": "127.0.0.1"}	2026-02-09 17:05:06.15851
a621e2e3-95df-44a2-9d77-67a2520cbce4	INFO	POST /questions - 201	api	17948a7e-86d4-4a22-94ef-70d7670eab6e	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 8.37, "client_ip": "127.0.0.1"}	2026-02-09 17:05:06.594483
5573cb67-7b07-4076-8bc0-db30bfca94ae	WARNING	POST /questions - 422	api	77c6bc43-9bb9-4321-8285-2dae67d13992	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 3.63, "client_ip": "127.0.0.1"}	2026-02-09 17:05:07.026631
98daf286-6f96-4dcc-b31c-b7e077f8c991	INFO	POST /questions - 201	api	2752d6d6-aa3a-43bf-89dc-6f73149e3bac	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 7.0, "client_ip": "127.0.0.1"}	2026-02-09 17:05:08.044893
417518c4-3dd6-481c-9b8b-c1830f3cd7c0	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.5, "client_ip": "127.0.0.1"}	2026-02-09 17:05:08.348331
73316f9b-fe68-468e-b1bf-605624f8c6fa	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	09cb97ae-9564-4602-bbcd-30e2792d7bb2	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 66.48, "client_ip": "127.0.0.1"}	2026-02-09 17:05:09.096994
26799561-b503-408b-acb6-3ba44c7c1d1d	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 5.67, "client_ip": "127.0.0.1"}	2026-02-10 07:30:22.738034
5a666f2e-19fa-4a6f-ba16-1c6fa21184fb	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 364.48, "client_ip": "127.0.0.1"}	2026-02-09 13:36:46.621421
aabf4d54-f6b8-4625-8996-fece20a511ed	WARNING	GET /agronomy/diagnostic-rules - 401	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 401, "duration_ms": 23.11, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.852445
f3d14eb4-3d9a-4406-ada7-bd48d2684e09	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 17.35, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.954838
821c435f-bd11-43e6-8b5a-195b7ef29613	INFO	POST /admin/experts/approve/bf630e89-7627-4c1c-b402-f3ac39a01db3 - 200	api	318dbd75-a04c-4d61-a595-4d0cee31dbe7	{"method": "POST", "path": "/admin/experts/approve/bf630e89-7627-4c1c-b402-f3ac39a01db3", "status_code": 200, "duration_ms": 2.95, "client_ip": "127.0.0.1"}	2026-02-09 17:11:33.247402
2c4094a2-9d98-4d27-88cc-0cd4ff74aea9	WARNING	GET /admin/dashboard - 403	api	098176dc-4126-4c15-a0fe-8aa68e6c74ee	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.53, "client_ip": "127.0.0.1"}	2026-02-09 17:11:35.386794
39e014fd-3937-49fa-a0b0-2dca29607357	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 0.89, "client_ip": "127.0.0.1"}	2026-02-09 17:11:37.279412
c1ca4dc5-017a-4178-a6bf-703ea298636b	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 267.43, "client_ip": "127.0.0.1"}	2026-02-09 17:11:37.734964
7f1422c8-210b-4574-89fb-b64e9f000b64	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 1.95, "client_ip": "127.0.0.1"}	2026-02-09 17:11:38.142791
556ec3fa-92c8-4d22-a99c-55b8ca36ca36	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 246.31, "client_ip": "127.0.0.1"}	2026-02-09 17:11:38.820605
b0c11907-0760-4c01-8a8b-640f8e1cb426	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 245.38, "client_ip": "127.0.0.1"}	2026-02-09 17:11:39.437096
170c39b0-1bfc-4635-8507-24bb0c3504f5	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 4.11, "client_ip": "127.0.0.1"}	2026-02-09 17:11:39.587164
f86e0f75-d6c4-4be3-a830-e69cc7252137	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.73, "client_ip": "127.0.0.1"}	2026-02-09 17:11:39.744371
94edbd34-a7d7-4032-bc7d-6e2c36085265	INFO	POST /community/posts - 201	api	857aefdb-f7f3-4bf3-9e30-36b9d3f336ab	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 12.08, "client_ip": "127.0.0.1"}	2026-02-09 17:11:41.01027
56efed72-fb16-441e-b328-0c32ea6283aa	WARNING	POST /community/posts - 422	api	cc69b354-f7c8-490f-a595-40720d0f7622	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.35, "client_ip": "127.0.0.1"}	2026-02-09 17:11:41.408372
dc516737-9196-47ae-bd43-78018968c781	INFO	POST /community/posts - 201	api	0c6cb955-1087-4b9c-8635-7e6f7aa774d9	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.33, "client_ip": "127.0.0.1"}	2026-02-09 17:11:41.812761
83740723-7aeb-4e76-9841-73ce55097781	INFO	POST /community/posts - 201	api	685ce86e-ec58-4504-963d-a6b1f55157ef	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.48, "client_ip": "127.0.0.1"}	2026-02-09 17:11:42.295919
06d75ed7-848c-4b81-9afb-966efcab81bf	INFO	POST /community/posts/c8ef0df8-dd1c-4550-93fb-3b6d268c8b34/like - 200	api	685ce86e-ec58-4504-963d-a6b1f55157ef	{"method": "POST", "path": "/community/posts/c8ef0df8-dd1c-4550-93fb-3b6d268c8b34/like", "status_code": 200, "duration_ms": 8.17, "client_ip": "127.0.0.1"}	2026-02-09 17:11:42.306177
c62d3634-986b-4f7e-9d67-d3b725dccf06	INFO	POST /community/posts - 201	api	bc208ca7-28d3-42fc-aa7b-8ef6e89aa08c	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.47, "client_ip": "127.0.0.1"}	2026-02-09 17:11:42.748079
194e7305-c8d0-4e7d-9a39-7a56f253f1dd	INFO	POST /community/posts/8fa57bdb-c9cc-4a2c-b425-743f6e229ec9/comments - 201	api	bc208ca7-28d3-42fc-aa7b-8ef6e89aa08c	{"method": "POST", "path": "/community/posts/8fa57bdb-c9cc-4a2c-b425-743f6e229ec9/comments", "status_code": 201, "duration_ms": 7.64, "client_ip": "127.0.0.1"}	2026-02-09 17:11:42.75781
61d193ee-4503-4dcc-a4ff-3cebb5de1708	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 305.53, "client_ip": "127.0.0.1"}	2026-02-10 07:37:58.565242
58f1854c-75de-4e8e-84d6-f20f68337a89	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 295.21, "client_ip": "127.0.0.1"}	2026-02-11 19:30:39.382184
7d6e3280-26a1-4b4d-a47e-885449fa28fa	WARNING	GET /market/prices - 401	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 401, "duration_ms": 1.96, "client_ip": "127.0.0.1"}	2026-02-11 19:31:28.283089
c3c90f8f-96de-4dde-aee2-b945ae26eeff	WARNING	GET /agronomy/seasonal-patterns - 401	api	\N	{"method": "GET", "path": "/agronomy/seasonal-patterns", "status_code": 401, "duration_ms": 14.37, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.859004
17cac8f6-252c-4e79-a6e1-b2d6cc3c8b96	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 17.84, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.955828
7d551398-b9b5-4182-a494-b374e22266e6	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.59, "client_ip": "127.0.0.1"}	2026-02-09 17:11:43.679115
8be4ec1f-bc52-443b-8d3b-a01db1d379b5	INFO	POST /expert/answer - 201	api	5268e6de-c2c6-41b2-8ca1-45de6aa11d39	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.63, "client_ip": "127.0.0.1"}	2026-02-09 17:11:47.79005
5a2106bd-647d-4e35-af00-2ede0b26e1f2	INFO	POST /expert/answer - 201	api	e7b6e7b6-3b09-430a-b91e-fb891ccb23b6	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 7.81, "client_ip": "127.0.0.1"}	2026-02-09 17:11:48.435488
a72723a5-f4bd-4796-8f3d-bcc933d6e193	WARNING	POST /expert/answer - 409	api	e7b6e7b6-3b09-430a-b91e-fb891ccb23b6	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.44, "client_ip": "127.0.0.1"}	2026-02-09 17:11:48.440328
68d56cda-9c12-4b76-8170-3fcee2f27373	WARNING	GET /expert/questions - 403	api	dda90217-8192-4c46-88c8-3c985775dd2d	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 37.47, "client_ip": "127.0.0.1"}	2026-02-09 17:11:48.883968
534f754a-4ec2-4994-a215-51ec9f30e752	INFO	PUT /expert/profile - 200	api	e5fc8adc-58ee-4cec-86db-68947703ca04	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.06, "client_ip": "127.0.0.1"}	2026-02-09 17:11:49.690494
79408f3b-40ae-41c4-8349-c503540424d3	INFO	POST /farm/crops - 201	api	22929912-afe3-420e-b472-a07ee07d9c16	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 18.13, "client_ip": "127.0.0.1"}	2026-02-09 17:11:51.006013
c817b596-833e-4c6a-84ba-ad3ebe835077	INFO	POST /farm/tasks - 201	api	b3d9f1e9-d3ab-4af6-9fa1-9b3305297faf	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 18.57, "client_ip": "127.0.0.1"}	2026-02-09 17:11:51.842548
dbe64289-830e-4160-8ce9-15d1e77615ed	INFO	POST /farm/tasks - 201	api	2efdb5de-b16d-4c5d-aed1-6e04b3ee3472	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 19.22, "client_ip": "127.0.0.1"}	2026-02-09 17:11:52.240567
a94a3292-3801-418f-93b4-cb8f43f01991	INFO	PUT /farm/tasks/17a91b5b-edea-4245-938a-6b5c01231c92/complete - 200	api	2efdb5de-b16d-4c5d-aed1-6e04b3ee3472	{"method": "PUT", "path": "/farm/tasks/17a91b5b-edea-4245-938a-6b5c01231c92/complete", "status_code": 200, "duration_ms": 4.82, "client_ip": "127.0.0.1"}	2026-02-09 17:11:52.252281
469c391e-21c3-4751-af68-7d0845ff5e48	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.69, "client_ip": "127.0.0.1"}	2026-02-09 17:11:53.59909
ea643306-757a-4021-a08d-b681dcdbe5f4	INFO	POST /questions - 201	api	306d16b1-bc17-4092-aac6-38ad98a8cfca	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.86, "client_ip": "127.0.0.1"}	2026-02-09 17:11:54.020098
481ce98e-ed3c-4837-9b16-c4f2ce523aef	WARNING	POST /questions - 422	api	13342117-f736-4454-a47b-e2c48a856cb3	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 2.67, "client_ip": "127.0.0.1"}	2026-02-09 17:11:54.428365
b0d0f488-1d81-488e-a65e-95271112329a	INFO	POST /questions - 201	api	aa5a82fc-482b-4c4b-9727-063950e5da89	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 4.98, "client_ip": "127.0.0.1"}	2026-02-09 17:11:55.200271
52878d0b-7518-49e7-9e0e-4d06d450a25b	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.6, "client_ip": "127.0.0.1"}	2026-02-09 17:11:55.327018
d1b71b49-7c40-4ad4-8fb7-373f24b85e3b	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	83b3c298-6221-436b-a073-c1d256679360	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.36, "client_ip": "127.0.0.1"}	2026-02-09 17:11:55.708831
05fdb1f2-e523-4759-827d-b1b0674a79b6	WARNING	GET /expert/stats - 401	api	\N	{"method": "GET", "path": "/expert/stats", "status_code": 401, "duration_ms": 0.51, "client_ip": "127.0.0.1"}	2026-02-10 07:38:02.220965
e1c310a7-8a2e-4afd-a4be-eb20de936180	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 335.46, "client_ip": "127.0.0.1"}	2026-02-11 19:35:04.621888
4d3b8454-e0e9-4aef-9de6-3f0abf25d59e	WARNING	GET /encyclopedia/diseases - 401	api	\N	{"method": "GET", "path": "/encyclopedia/diseases", "status_code": 401, "duration_ms": 3.36, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.896369
cd3750b0-6d75-4d65-bb60-0b62fa417ffb	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 21.06, "client_ip": "127.0.0.1"}	2026-02-09 13:39:24.959048
ddd88e10-97ba-43b0-baf9-219dd4b47470	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 13.64, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.825343
62236f5e-bf53-413e-99d1-5b540f9d608b	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.7, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.86548
57d963de-463f-42ae-98fc-07ae46bee982	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 0.87, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.895363
bd8e9dfc-f136-4924-aeeb-c6c9a1414063	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.2, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.907058
f63f34a8-a251-4b00-ab99-1feb008feed7	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.37, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.924234
1f296590-7c3f-486d-9ccc-984b06961b40	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 333.13, "client_ip": "127.0.0.1"}	2026-02-09 17:43:40.812612
9e919fb4-6099-48dd-ad70-3f80ca405faf	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 26.47, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.111585
63c705e2-332e-444d-abf0-8beaf8df3e0d	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.65, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.158738
a599eb53-5649-4b6c-92e5-187f5a787228	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 1.23, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.196037
263b8a47-78e8-48f8-ac71-3707e8928ad5	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 0.68, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.21332
273c8d0e-ddd6-4e2a-9a0a-0f72f44d9f9c	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 0.51, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.245403
cf0c7450-f759-4684-9112-572316e8c1f6	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 334.7, "client_ip": "127.0.0.1"}	2026-02-10 09:01:22.452253
3302ff55-e84a-4083-bb20-0d4c768e1df7	INFO	POST /auth/verify - 200	api	\N	{"method": "POST", "path": "/auth/verify", "status_code": 200, "duration_ms": 71.89, "client_ip": "127.0.0.1"}	2026-02-10 09:10:28.6257
0d3c8218-8469-4b35-936e-486dde281741	INFO	POST /diagnosis/predict - 200	api	1ddb77c7-5db3-4d9b-837b-2dd5bb76cb98	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 223.29, "client_ip": "127.0.0.1"}	2026-02-10 09:30:16.529846
4cac8fd4-12d9-40a2-9425-e9b68ec18e73	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 25.65, "client_ip": "127.0.0.1"}	2026-02-10 09:31:23.039845
b386d6d7-f4d1-447f-90ae-c453ba636114	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 1.23, "client_ip": "127.0.0.1"}	2026-02-10 09:31:23.062205
ae8a694c-4700-41e0-9826-faea889a8ced	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 290.87, "client_ip": "127.0.0.1"}	2026-02-10 09:31:32.024177
810fe233-c259-4cc1-a370-94136f1fb8d5	WARNING	GET /expert/stats - 401	api	\N	{"method": "GET", "path": "/expert/stats", "status_code": 401, "duration_ms": 9.74, "client_ip": "127.0.0.1"}	2026-02-10 09:39:35.953889
65ce212a-3606-4ed0-98cf-0737c5df3158	CRITICAL	Unhandled Exception: 10 validation errors:\n  {'type': 'missing', 'loc': ('response', 'prices', 0, 'created_at'), 'msg': '	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/market/prices", "error": "10 validation errors:\\n  {'type': 'missing', 'loc': ('response', 'prices', 0, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Pipariya APMC_Green Gram(Moong)(Whole)_11/02/2026', 'commodity': 'Green Gram(Moong)(Whole)', 'price': 7461.0, 'unit': 'Quintal', 'location': 'Pipariya APMC, Hoshangabad, Madhya Pradesh', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1300.0, 'max_price': 7461.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354614), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354617)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 1, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Sirali APMC_Wheat_11/02/2026', 'commodity': 'Wheat', 'price': 2500.0, 'unit': 'Quintal', 'location': 'Sirali APMC, Harda, Madhya Pradesh', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 2450.0, 'max_price': 2559.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354623), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354623)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 2, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Dhragradhra APMC_Isabgul(Psyllium)_11/02/2026', 'commodity': 'Isabgul(Psyllium)', 'price': 8650.0, 'unit': 'Quintal', 'location': 'Dhragradhra APMC, Surendranagar, Gujarat', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 8650.0, 'max_price': 8650.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354625), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354626)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 3, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Jodhpur (F&V) APMC_Bottle gourd_11/02/2026', 'commodity': 'Bottle gourd', 'price': 1000.0, 'unit': 'Quintal', 'location': 'Jodhpur (F&V) APMC, Jodhpur, Rajasthan', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 800.0, 'max_price': 1500.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354628), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354628)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 4, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Jodhpur (F&V) APMC_Capsicum_11/02/2026', 'commodity': 'Capsicum', 'price': 2500.0, 'unit': 'Quintal', 'location': 'Jodhpur (F&V) APMC, Jodhpur, Rajasthan', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 2000.0, 'max_price': 3000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354630), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354630)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 5, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Jodhpur (F&V) APMC_Carrot_11/02/2026', 'commodity': 'Carrot', 'price': 800.0, 'unit': 'Quintal', 'location': 'Jodhpur (F&V) APMC, Jodhpur, Rajasthan', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 600.0, 'max_price': 1200.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354632), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354632)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 6, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Jodhpur (F&V) APMC_Apple_11/02/2026', 'commodity': 'Apple', 'price': 7500.0, 'unit': 'Quintal', 'location': 'Jodhpur (F&V) APMC, Jodhpur, Rajasthan', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 5000.0, 'max_price': 10000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354634), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354634)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 7, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Jodhpur (F&V) APMC_Mousambi(Sweet Lime)_11/02/2026', 'commodity': 'Mousambi(Sweet Lime)', 'price': 1700.0, 'unit': 'Quintal', 'location': 'Jodhpur (F&V) APMC, Jodhpur, Rajasthan', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1500.0, 'max_price': 3000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354636), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354637)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 8, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Sulya APMC_Black pepper_11/02/2026', 'commodity': 'Black pepper', 'price': 60000.0, 'unit': 'Quintal', 'location': 'Sulya APMC, Mangalore(Dakshin Kannad), Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 32000.0, 'max_price': 70000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354638), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354639)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 9, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Sulya APMC_Arecanut(Betelnut/Supari)_11/02/2026', 'commodity': 'Arecanut(Betelnut/Supari)', 'price': 45000.0, 'unit': 'Quintal', 'location': 'Sulya APMC, Mangalore(Dakshin Kannad), Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 34500.0, 'max_price': 47000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354641), 'updated_at': datetime.datetime(2026, 2, 12, 1, 8, 51, 354641)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n"}	2026-02-11 19:38:51.359676
83734caf-4ccc-4231-85c5-a69af5a3eacd	CRITICAL	Unhandled Exception: 10 validation errors:\n  {'type': 'missing', 'loc': ('response', 'prices', 0, 'created_at'), 'msg': '	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "GET", "path": "/market/prices", "error": "10 validation errors:\\n  {'type': 'missing', 'loc': ('response', 'prices', 0, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Gowribidanoor APMC_Beetroot_11/02/2026', 'commodity': 'Beetroot', 'price': 2000.0, 'unit': 'Quintal', 'location': 'Gowribidanoor APMC, Kolar, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1500.0, 'max_price': 2500.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829639), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829642)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 1, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Gowribidanoor APMC_Ridgeguard(Tori)_11/02/2026', 'commodity': 'Ridgeguard(Tori)', 'price': 1500.0, 'unit': 'Quintal', 'location': 'Gowribidanoor APMC, Kolar, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1000.0, 'max_price': 2000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829651), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829652)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 2, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Malur APMC_Beans_11/02/2026', 'commodity': 'Beans', 'price': 3000.0, 'unit': 'Quintal', 'location': 'Malur APMC, Kolar, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 2500.0, 'max_price': 3500.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829654), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829654)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 3, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Malur APMC_Jaggery_11/02/2026', 'commodity': 'Jaggery', 'price': 4383.0, 'unit': 'Quintal', 'location': 'Malur APMC, Kolar, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 4000.0, 'max_price': 5000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829656), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829656)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 4, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Gundlupet APMC_Tomato_11/02/2026', 'commodity': 'Tomato', 'price': 1500.0, 'unit': 'Quintal', 'location': 'Gundlupet APMC, Chamrajnagar, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1500.0, 'max_price': 1500.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829658), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829658)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 5, 'created_at'), 'msg': 'Field required', 'input': {'id': 'K.R. Pet APMC_Paddy(Common)_11/02/2026', 'commodity': 'Paddy(Common)', 'price': 2000.0, 'unit': 'Quintal', 'location': 'K.R. Pet APMC, Mandya, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 2000.0, 'max_price': 2200.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829660), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829660)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 6, 'created_at'), 'msg': 'Field required', 'input': {'id': 'K.R. Pet APMC_Tender Coconut_11/02/2026', 'commodity': 'Tender Coconut', 'price': 21000.0, 'unit': 'Quintal', 'location': 'K.R. Pet APMC, Mandya, Karnataka', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 10000.0, 'max_price': 40000.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829662), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829663)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 7, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Chhindwara APMC_Maize_11/02/2026', 'commodity': 'Maize', 'price': 1600.0, 'unit': 'Quintal', 'location': 'Chhindwara APMC, Chhindwara, Madhya Pradesh', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1306.0, 'max_price': 1700.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829664), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829665)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 8, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Dhar APMC_Maize_11/02/2026', 'commodity': 'Maize', 'price': 1596.0, 'unit': 'Quintal', 'location': 'Dhar APMC, Dhar, Madhya Pradesh', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 1300.0, 'max_price': 1596.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829666), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829667)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n  {'type': 'missing', 'loc': ('response', 'prices', 9, 'created_at'), 'msg': 'Field required', 'input': {'id': 'Itarsi APMC_Soyabean_11/02/2026', 'commodity': 'Soyabean', 'price': 4500.0, 'unit': 'Quintal', 'location': 'Itarsi APMC, Hoshangabad, Madhya Pradesh', 'trend': 'stable', 'change_percent': 0.0, 'min_price': 4200.0, 'max_price': 5151.0, 'arrival_qty': 0.0, 'recorded_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829675), 'updated_at': datetime.datetime(2026, 2, 12, 1, 9, 12, 829675)}, 'url': 'https://errors.pydantic.dev/2.5/v/missing'}\\n"}	2026-02-11 19:39:12.831754
57d25861-a235-49b2-9e83-49e88d04ca69	WARNING	POST /admin/experts/99969296-271a-4e64-bb6c-c6b564fbd91c/approve - 404	api	e8e8fec1-66e7-4b33-b5d2-2dc9ae897ac8	{"method": "POST", "path": "/admin/experts/99969296-271a-4e64-bb6c-c6b564fbd91c/approve", "status_code": 404, "duration_ms": 0.81, "client_ip": "127.0.0.1"}	2026-02-09 14:17:38.90725
71728c76-81ba-4e1a-8f2c-b3487f54a6e4	WARNING	GET /admin/dashboard - 403	api	8591d3c1-aa49-4477-b952-2d313846dbbc	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.66, "client_ip": "127.0.0.1"}	2026-02-09 14:17:39.370619
22d78279-1cee-4c7a-8b26-c4e96a1c0c66	WARNING	POST /agronomy/diagnostic-rules - 422	api	6899a274-a215-4a58-99ae-a5d81089eaa8	{"method": "POST", "path": "/agronomy/diagnostic-rules", "status_code": 422, "duration_ms": 4.78, "client_ip": "127.0.0.1"}	2026-02-09 14:17:41.695742
e9d51821-e51f-4a6a-8f23-b8eb8f159063	WARNING	POST /agronomy/diagnostic-rules - 403	api	70e1a4f6-d029-4d11-80a9-141449daccbf	{"method": "POST", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 2.52, "client_ip": "127.0.0.1"}	2026-02-09 14:17:42.138238
3fb8cd0d-ac98-4b65-aa4b-6496c50d044b	CRITICAL	Unhandled Exception: app.agronomy.models.TreatmentConstraint() argument after ** must be a mapping, not TreatmentConstrai	api	a3783998-336d-4cf1-be4b-cd8a34b5a417	{"method": "POST", "path": "/agronomy/treatment-constraints", "error": "app.agronomy.models.TreatmentConstraint() argument after ** must be a mapping, not TreatmentConstraintCreate"}	2026-02-09 14:17:42.528462
abc8e1a3-98d3-4f70-ba6c-d3d5fe41a5e2	WARNING	POST /agronomy/seasonal-patterns - 422	api	f455b4fa-bb30-4f94-99cd-579fa161f8b2	{"method": "POST", "path": "/agronomy/seasonal-patterns", "status_code": 422, "duration_ms": 3.48, "client_ip": "127.0.0.1"}	2026-02-09 14:17:43.091124
92eea43d-e295-46d1-888c-9a4d7457ce84	WARNING	DELETE /agronomy/diagnostic-rules/e4c5995c-c111-425e-999e-7e8c8a7022c2 - 403	api	a4ead12a-28b6-4ee6-90eb-9f808874e8b7	{"method": "DELETE", "path": "/agronomy/diagnostic-rules/e4c5995c-c111-425e-999e-7e8c8a7022c2", "status_code": 403, "duration_ms": 2.07, "client_ip": "127.0.0.1"}	2026-02-09 14:17:43.503951
da2bf861-ffbe-479d-b193-305590a688ee	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 270.76, "client_ip": "127.0.0.1"}	2026-02-09 14:17:44.036212
87b197af-104f-477a-8051-ebc6b0221184	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.23, "client_ip": "127.0.0.1"}	2026-02-09 14:17:44.434286
641c92d4-80ca-4c82-98ce-b8d7fc8d0055	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 244.81, "client_ip": "127.0.0.1"}	2026-02-09 14:17:45.072163
a0541c3f-6c77-409e-afc7-d8c12671df93	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 245.44, "client_ip": "127.0.0.1"}	2026-02-09 14:17:45.751507
7ffc3098-f5fd-4771-874e-15f955389e22	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 4.08, "client_ip": "127.0.0.1"}	2026-02-09 14:17:45.93115
b574d089-ecd7-43b8-8d20-989314ff5b3a	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.82, "client_ip": "127.0.0.1"}	2026-02-09 14:17:46.095554
e586bc76-510a-4a1e-89ce-1b38b633ffef	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 1.21, "client_ip": "127.0.0.1"}	2026-02-09 17:43:33.916498
b20e349d-88dc-4083-95b4-25ccbc12abc6	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 1.83, "client_ip": "127.0.0.1"}	2026-02-10 09:00:27.239305
cd2a190e-d0ae-466b-a88f-0f7a1544adcb	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 321.56, "client_ip": "127.0.0.1"}	2026-02-10 09:10:15.629501
c81fd2bb-5720-4abe-90e9-d13764bb6849	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 17.1, "client_ip": "127.0.0.1"}	2026-02-10 09:31:23.043659
42ff47ef-a74b-40ac-b755-3f54f46116a0	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 1.61, "client_ip": "127.0.0.1"}	2026-02-10 09:31:23.063091
18ed9f8e-1b13-4e52-86fb-bc55a48eabce	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 310.21, "client_ip": "127.0.0.1"}	2026-02-10 09:38:41.787885
b6e80a81-c831-4a2f-9714-3dc70b613147	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 263.02, "client_ip": "127.0.0.1"}	2026-02-10 09:38:58.600419
20c54b70-ba3a-4eb7-b790-2e413659590a	INFO	POST /auth/login - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 314.91, "client_ip": "127.0.0.1"}	2026-02-11 19:45:31.759208
72bfcd5b-2ce7-4695-bc70-93cbdd712aaf	INFO	POST /community/posts - 201	api	be6cb5e4-944c-483d-b2c0-18b008ab6aa0	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.87, "client_ip": "127.0.0.1"}	2026-02-09 14:17:47.494757
3166f0ea-7a8d-4291-846d-36f155a41f8d	WARNING	POST /community/posts - 422	api	38abe881-48f8-4e58-ad1c-c7a5fa06b68b	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.04, "client_ip": "127.0.0.1"}	2026-02-09 14:17:47.959916
26a40182-978f-44d0-bf27-d5e94a33f3d8	INFO	POST /community/posts - 201	api	73b91fae-4016-4406-84b3-fee1a2d15d19	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.18, "client_ip": "127.0.0.1"}	2026-02-09 14:17:48.400608
0ae78dbb-5fb7-4be1-8d86-327196e0b731	INFO	POST /community/posts - 201	api	8b3c3e79-4ea6-439b-8f04-01f6e3f6bde4	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.17, "client_ip": "127.0.0.1"}	2026-02-09 14:17:48.850119
ea9b37d4-e341-42b8-8e8a-d8a8ca8a5d98	INFO	POST /community/posts/83d4d795-f354-40e5-b459-0392f544d4ce/like - 200	api	8b3c3e79-4ea6-439b-8f04-01f6e3f6bde4	{"method": "POST", "path": "/community/posts/83d4d795-f354-40e5-b459-0392f544d4ce/like", "status_code": 200, "duration_ms": 8.8, "client_ip": "127.0.0.1"}	2026-02-09 14:17:48.861146
a658dba8-0b14-43a5-8c5f-2a331f339d52	INFO	POST /community/posts - 201	api	bec3e4b1-0e0c-4fb5-a1c9-543dff7f0cbf	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 7.51, "client_ip": "127.0.0.1"}	2026-02-09 14:17:49.27597
3f5a9402-fbdb-4951-b81c-99712e6dd7f3	INFO	POST /community/posts/3017408a-6c4e-4d08-8156-5047ead4326a/comments - 201	api	bec3e4b1-0e0c-4fb5-a1c9-543dff7f0cbf	{"method": "POST", "path": "/community/posts/3017408a-6c4e-4d08-8156-5047ead4326a/comments", "status_code": 201, "duration_ms": 7.66, "client_ip": "127.0.0.1"}	2026-02-09 14:17:49.285946
b843e609-c285-47e5-a51d-f89cf3b970e6	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.74, "client_ip": "127.0.0.1"}	2026-02-09 14:17:50.358166
6db58284-611e-4250-af4c-00a9447a1854	WARNING	GET /expert/dashboard - 404	api	2aa606e5-ed22-486a-bb8c-d24cfe7abf1b	{"method": "GET", "path": "/expert/dashboard", "status_code": 404, "duration_ms": 0.52, "client_ip": "127.0.0.1"}	2026-02-09 14:17:53.179927
416edb32-0672-4a39-a7e7-dbae2a5dbc1a	WARNING	GET /expert/dashboard - 404	api	1d0a4900-f335-489f-b279-45d142dddcfe	{"method": "GET", "path": "/expert/dashboard", "status_code": 404, "duration_ms": 0.54, "client_ip": "127.0.0.1"}	2026-02-09 14:17:54.510965
3c6b532c-19e2-4358-b08f-43ed426ec014	INFO	POST /farm/crops - 201	api	3f65b8a8-26ed-49cb-acde-2bf20649fc5e	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 18.23, "client_ip": "127.0.0.1"}	2026-02-09 14:17:55.421043
5f950c57-5965-43bc-b488-92c8b4675392	INFO	POST /farm/tasks - 201	api	2c103e70-4565-45b5-bc32-a0cdfdb9f815	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 19.75, "client_ip": "127.0.0.1"}	2026-02-09 14:17:56.220504
acd11557-223b-4e82-b1c1-a1581e990a45	INFO	POST /farm/tasks - 201	api	2563b562-e54a-48be-acdc-0f6012d2cf72	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.39, "client_ip": "127.0.0.1"}	2026-02-09 14:17:56.627533
2f7a7409-44b2-480c-9584-5f5f5ff5343a	INFO	PUT /farm/tasks/b7f436eb-3d95-415d-8915-8972a3bc468b/complete - 200	api	2563b562-e54a-48be-acdc-0f6012d2cf72	{"method": "PUT", "path": "/farm/tasks/b7f436eb-3d95-415d-8915-8972a3bc468b/complete", "status_code": 200, "duration_ms": 5.32, "client_ip": "127.0.0.1"}	2026-02-09 14:17:56.635586
bd3676b6-d86a-4dfd-bd5c-ef5288c02e14	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.8, "client_ip": "127.0.0.1"}	2026-02-09 14:17:58.026779
db082fb5-2cc1-42f9-b357-691a0e19d912	INFO	POST /questions - 201	api	cc62c424-efff-4d9a-a0ea-338510eca7b0	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.48, "client_ip": "127.0.0.1"}	2026-02-09 14:17:58.428639
4ab72d3f-56b9-4e51-806c-ffc124839e12	WARNING	POST /questions - 422	api	5ff3f806-be75-4f86-a435-5f1facf19dab	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 1.94, "client_ip": "127.0.0.1"}	2026-02-09 14:17:58.936386
57218c0e-08e5-44a4-a6c4-93f4a84f4d7f	INFO	POST /questions - 201	api	86d0d980-21b2-4419-809c-d1ec950314d1	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.21, "client_ip": "127.0.0.1"}	2026-02-09 14:17:59.694245
937f748b-c0ab-48af-8e71-25cf0c1b2d66	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.83, "client_ip": "127.0.0.1"}	2026-02-09 14:17:59.884109
19a2b918-4a05-49ec-9702-40ccfadb8c77	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	1b1b1454-421f-4567-b84e-3aec3a5066f2	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.33, "client_ip": "127.0.0.1"}	2026-02-09 14:18:00.370733
cc2c2ae3-e01e-4756-adff-9213f20ed48a	WARNING	POST /diagnosis/bfbb4ac6-2f75-43b5-9520-dd3272923d0e/rate - 422	api	b34f614b-c5b4-480f-b19b-57c2f298efa5	{"method": "POST", "path": "/diagnosis/bfbb4ac6-2f75-43b5-9520-dd3272923d0e/rate", "status_code": 422, "duration_ms": 1.56, "client_ip": "127.0.0.1"}	2026-02-09 14:18:00.801979
58b863c0-574a-41d7-93e3-d9128b2b6cb6	WARNING	POST /diagnosis/e2f34d60-fb04-492e-93a3-658bfc489507/rate - 422	api	6c458b76-164c-46ca-bc89-435f1b41d953	{"method": "POST", "path": "/diagnosis/e2f34d60-fb04-492e-93a3-658bfc489507/rate", "status_code": 422, "duration_ms": 1.64, "client_ip": "127.0.0.1"}	2026-02-09 14:18:01.238639
47d64384-c4ef-4307-9501-da543b62f69f	INFO	POST /admin/experts/approve/07e4a32d-5649-41e4-9de1-e8556962efca - 200	api	550d0fd2-3c32-499d-8ae4-bd9f4e14c55b	{"method": "POST", "path": "/admin/experts/approve/07e4a32d-5649-41e4-9de1-e8556962efca", "status_code": 200, "duration_ms": 3.18, "client_ip": "127.0.0.1"}	2026-02-09 18:26:27.508887
42cf563e-4e4c-42ec-ad0a-b15d25813e83	WARNING	GET /admin/dashboard - 403	api	39cdbd89-d239-4a79-bed5-bdac7cbe9e0e	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.52, "client_ip": "127.0.0.1"}	2026-02-09 18:26:29.62738
c8ff182a-7da9-4a6f-960a-79e3e9d268ab	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 1.01, "client_ip": "127.0.0.1"}	2026-02-09 18:26:31.600526
8b9d478e-15ed-4bba-b41a-a894d401b74c	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 279.05, "client_ip": "127.0.0.1"}	2026-02-09 18:26:32.048955
89e646a5-987a-4f44-86d1-1a581e09f464	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.4, "client_ip": "127.0.0.1"}	2026-02-09 18:26:32.456636
9be7f43e-a6dd-4327-8274-bb9b93ed2552	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 245.89, "client_ip": "127.0.0.1"}	2026-02-09 18:26:33.133186
3d64424d-c44e-447d-ac3a-ad926de7e042	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 245.39, "client_ip": "127.0.0.1"}	2026-02-09 18:26:33.759311
e84ab0c3-b01c-4080-8e6a-8d540717ef5d	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 3.8, "client_ip": "127.0.0.1"}	2026-02-09 18:26:33.924138
5d01bfff-45d2-478b-91c8-880aa593f80e	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.81, "client_ip": "127.0.0.1"}	2026-02-09 18:26:34.112133
d4d88b03-48ac-4f18-8e22-8dde7ff6bb75	INFO	POST /community/posts - 201	api	b70c5908-c113-407d-a597-99a2eb490f96	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.07, "client_ip": "127.0.0.1"}	2026-02-09 18:26:35.447202
dd307f0a-69db-4707-b0ae-ab2d0f414427	WARNING	POST /community/posts - 422	api	acb29b3f-563a-4cb8-910e-c0e8330dfaa8	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.59, "client_ip": "127.0.0.1"}	2026-02-09 18:26:35.865377
89a067ae-2316-491a-a3c0-189a19605ff5	INFO	POST /community/posts - 201	api	a8ce9ef0-5429-49ea-8bfb-86268576498b	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.25, "client_ip": "127.0.0.1"}	2026-02-09 18:26:36.322245
5d3b10d6-c9fd-4977-a7f8-0f95288144bd	INFO	POST /community/posts - 201	api	030e655b-72a5-44cc-9956-dd4c4fa82d6c	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.12, "client_ip": "127.0.0.1"}	2026-02-09 18:26:36.74882
366762c1-b5b4-47f5-a73a-228f27e2e2dc	INFO	POST /admin/experts/approve/6f2ddd7a-e9b2-4706-81f8-f117af2044d1 - 200	api	4318507f-edb5-492b-9488-7723084f64c1	{"method": "POST", "path": "/admin/experts/approve/6f2ddd7a-e9b2-4706-81f8-f117af2044d1", "status_code": 200, "duration_ms": 3.23, "client_ip": "127.0.0.1"}	2026-02-09 14:20:30.428764
f28a8a6f-56f1-4da6-a3dd-6ade3ccc302b	WARNING	GET /admin/dashboard - 403	api	7d8cdfc3-e6a8-45eb-b545-eeba223d183e	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.63, "client_ip": "127.0.0.1"}	2026-02-09 14:20:32.640031
74e62751-d9b3-40c7-830c-8915b653fcdf	INFO	POST /expert/answer - 201	api	2d401c6c-4f10-4293-9bf6-82d9dcb5ee16	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 9.42, "client_ip": "127.0.0.1"}	2026-02-09 14:20:35.306524
4de2f195-da08-4460-bd35-b8d476d5cfb5	INFO	POST /expert/answer - 201	api	5249186b-b158-4470-befd-6ba63d37f72b	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.17, "client_ip": "127.0.0.1"}	2026-02-09 14:20:35.945028
5e573b42-fe8c-487c-8d1e-81f4a007a587	WARNING	POST /expert/answer - 409	api	5249186b-b158-4470-befd-6ba63d37f72b	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.32, "client_ip": "127.0.0.1"}	2026-02-09 14:20:35.94963
2223a061-f7ac-44df-825c-d1c658f41b84	WARNING	GET /expert/questions - 403	api	75970da1-778d-440f-853d-097e72bcb3b3	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 1.57, "client_ip": "127.0.0.1"}	2026-02-09 14:20:36.363356
a8e5396d-307a-44d9-896f-51ed293d29a9	INFO	PUT /expert/profile - 200	api	2243166a-5ea4-4e00-ae4b-269d280fe8b8	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.14, "client_ip": "127.0.0.1"}	2026-02-09 14:20:37.157728
18271faa-1a36-473a-bfe9-037336af9042	INFO	POST /community/posts/6587f44d-4aab-46e7-bf0a-b64adbc2c31a/like - 200	api	030e655b-72a5-44cc-9956-dd4c4fa82d6c	{"method": "POST", "path": "/community/posts/6587f44d-4aab-46e7-bf0a-b64adbc2c31a/like", "status_code": 200, "duration_ms": 8.95, "client_ip": "127.0.0.1"}	2026-02-09 18:26:36.76001
3562bce8-cccc-49cd-8820-9fb0e8a24617	INFO	POST /community/posts - 201	api	f8de7e00-3d1c-47a5-bdcb-7ecfaf61232b	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.14, "client_ip": "127.0.0.1"}	2026-02-09 18:26:37.195529
8ac25937-714b-4990-b20c-5d496b84ea2f	INFO	POST /community/posts/4a960811-40a6-4fce-9f00-cc5aa7bf1e4f/comments - 201	api	f8de7e00-3d1c-47a5-bdcb-7ecfaf61232b	{"method": "POST", "path": "/community/posts/4a960811-40a6-4fce-9f00-cc5aa7bf1e4f/comments", "status_code": 201, "duration_ms": 8.05, "client_ip": "127.0.0.1"}	2026-02-09 18:26:37.205769
4dd8f9ff-f8d3-41ef-a33e-16a4d812623b	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.65, "client_ip": "127.0.0.1"}	2026-02-09 18:26:38.211103
693b37a0-0459-453e-9dc0-2bd677ade8bf	INFO	POST /expert/answer - 201	api	8f7286d7-4372-4293-852d-caa428440198	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.43, "client_ip": "127.0.0.1"}	2026-02-09 18:26:42.574525
968bf040-66e3-48f1-9a6c-88864fc39e29	INFO	POST /expert/answer - 201	api	578a7f65-ef2b-4b71-807b-e31dbc7fb487	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.11, "client_ip": "127.0.0.1"}	2026-02-09 18:26:43.218621
66666f7a-40f6-41ab-8af6-beef7b0d2a0a	WARNING	POST /expert/answer - 409	api	578a7f65-ef2b-4b71-807b-e31dbc7fb487	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.46, "client_ip": "127.0.0.1"}	2026-02-09 18:26:43.22349
0f53b272-b3e2-4cef-9681-e58821ffdfe3	WARNING	GET /expert/questions - 403	api	a41a7afd-2bd8-4491-a83d-22e506d0670f	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 34.91, "client_ip": "127.0.0.1"}	2026-02-09 18:26:43.687317
bca5fc40-49f3-45cb-bc02-f36e17a6bb1d	INFO	PUT /expert/profile - 200	api	b267bcc9-49f0-4b54-b620-e2de431842ac	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.06, "client_ip": "127.0.0.1"}	2026-02-09 18:26:44.512661
1eaeb20f-a177-47ed-8b63-bf154bbf37e5	INFO	POST /farm/crops - 201	api	a98cacd7-74cf-4fde-85a2-35a3ca89ca24	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 20.08, "client_ip": "127.0.0.1"}	2026-02-09 18:26:45.780621
3c00e47a-25fe-48fd-bd57-2ac4446d9b4a	INFO	POST /farm/tasks - 201	api	8779efdb-9a65-4aef-ab6f-3c519ee81c71	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.03, "client_ip": "127.0.0.1"}	2026-02-09 18:26:46.592211
849c0e5d-ca36-4710-8f52-a125e83a33dc	INFO	POST /farm/tasks - 201	api	15630410-8cc5-47ce-acc1-d9b49ad000b5	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 21.51, "client_ip": "127.0.0.1"}	2026-02-09 18:26:46.992424
ffa03827-3be0-452a-8954-5a305194bdda	INFO	PUT /farm/tasks/3043915f-6bf8-4993-a46f-72f9f76afe52/complete - 200	api	15630410-8cc5-47ce-acc1-d9b49ad000b5	{"method": "PUT", "path": "/farm/tasks/3043915f-6bf8-4993-a46f-72f9f76afe52/complete", "status_code": 200, "duration_ms": 5.54, "client_ip": "127.0.0.1"}	2026-02-09 18:26:47.000512
be98feef-74c9-4cc7-88e9-2705a9a3db79	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.57, "client_ip": "127.0.0.1"}	2026-02-09 18:26:48.405328
f1b8639a-b2fc-4023-a1fe-ee7d84e4f864	INFO	POST /questions - 201	api	85e4d36b-b774-474d-9eb1-0c1b1d661dc2	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 4.77, "client_ip": "127.0.0.1"}	2026-02-09 18:26:48.778403
cbaef1b5-81a0-468e-aec0-fa15e6cba141	WARNING	POST /questions - 422	api	5e7479fa-ca84-4cff-8a3b-d618011081b1	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 1.86, "client_ip": "127.0.0.1"}	2026-02-09 18:26:49.193847
40c4bb84-4484-4242-aa11-ea17f40da711	INFO	POST /questions - 201	api	77a33c53-eee9-4d0d-9fcd-99924313a231	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.87, "client_ip": "127.0.0.1"}	2026-02-09 18:26:50.039784
e74c8b21-6d49-4035-aeed-c1cdddc61d79	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.52, "client_ip": "127.0.0.1"}	2026-02-09 18:26:50.160987
a5b308ae-66f3-4d22-b6df-7b0bc369ad79	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 544.16, "client_ip": "127.0.0.1"}	2026-02-12 04:46:57.068383
5406b4e1-5743-4f99-923e-832f1cb3311e	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 0.77, "client_ip": "127.0.0.1"}	2026-02-09 14:20:39.096524
227de776-2776-46de-b8fe-d17535317d06	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	42c94ecf-9caf-42a2-bc33-efcdd46821ae	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.16, "client_ip": "127.0.0.1"}	2026-02-09 18:26:50.59276
d9665a74-be45-4e4f-a721-5d7ca49d223a	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 474.63, "client_ip": "127.0.0.1"}	2026-02-18 05:51:31.002787
d75c37b6-b3f0-4903-b001-ecabace7627d	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 288.66, "client_ip": "127.0.0.1"}	2026-02-18 05:51:43.556671
f1e88eed-2f27-4c16-80f0-b2b0e7b497fc	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 135.72, "client_ip": "127.0.0.1"}	2026-02-18 05:52:33.842817
d22c4a80-88ad-4497-b8ba-bd8cd769a54b	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 17.03, "client_ip": "127.0.0.1"}	2026-02-18 05:52:38.873625
9e5304bb-bf73-43ca-affd-ed3aefb7ec57	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.75, "client_ip": "127.0.0.1"}	2026-02-18 05:52:38.917802
6315fa59-a850-4386-8eeb-3aecca9c46bc	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 0.99, "client_ip": "127.0.0.1"}	2026-02-18 05:52:38.954455
5292c54a-3095-49c8-8a20-2b11b719cc84	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 5.82, "client_ip": "127.0.0.1"}	2026-02-18 05:52:38.975307
e24f1918-4e8b-450a-ab52-9c0a086289b9	WARNING	GET /admin/metrics/daily - 401	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 401, "duration_ms": 0.75, "client_ip": "127.0.0.1"}	2026-02-18 05:52:38.991674
60d9b816-8d44-4c08-b980-834986d1b696	INFO	POST /admin/experts/approve/d4661b26-9769-4804-9653-17da0057626c - 200	api	c2dd812d-7f62-4590-bf1e-66e4ab050f69	{"method": "POST", "path": "/admin/experts/approve/d4661b26-9769-4804-9653-17da0057626c", "status_code": 200, "duration_ms": 3.25, "client_ip": "127.0.0.1"}	2026-02-09 14:20:52.332064
1c887762-f741-47d0-8f80-65a601b05ebf	WARNING	GET /admin/dashboard - 403	api	df5d60dd-3458-4d99-95ac-3c840218b56b	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.46, "client_ip": "127.0.0.1"}	2026-02-09 14:20:54.454983
eb685ab1-5e79-4763-9a5a-9a1c2605cb4e	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 0.91, "client_ip": "127.0.0.1"}	2026-02-09 14:20:56.335138
d843bc75-6b71-44e0-b7c6-6263f3e99994	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 258.79, "client_ip": "127.0.0.1"}	2026-02-09 14:20:56.701457
56e6e7ff-2c99-41bd-97a5-403e78455181	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.22, "client_ip": "127.0.0.1"}	2026-02-09 14:20:57.122867
259046c3-e173-4201-9a22-9e2173f23656	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 245.86, "client_ip": "127.0.0.1"}	2026-02-09 14:20:57.786389
cf4a06cc-f0eb-4164-ba32-71eb32d9388a	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 245.73, "client_ip": "127.0.0.1"}	2026-02-09 14:20:58.439155
3f69d46b-8f29-49dd-9f8a-3c5a0a70479d	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 3.6, "client_ip": "127.0.0.1"}	2026-02-09 14:20:58.613881
a64f6445-8f59-416d-b46a-3068f62f36be	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.58, "client_ip": "127.0.0.1"}	2026-02-09 14:20:58.754483
6544a7fa-ccb2-4856-b6f7-c23c47f3d97e	INFO	POST /community/posts - 201	api	d5b1e09c-983d-4d03-8143-871fcf41582e	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.97, "client_ip": "127.0.0.1"}	2026-02-09 14:20:59.979371
417a3335-5ef2-4e0f-89ae-76ff89a322fc	WARNING	POST /community/posts - 422	api	e70e4fd5-541c-4de7-b0c2-c23fcff5dbf8	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.55, "client_ip": "127.0.0.1"}	2026-02-09 14:21:00.412342
8227be22-d5b1-4f95-8d63-b4a34d670016	INFO	POST /community/posts - 201	api	88407773-3d08-447f-a16b-d9ac932ca99f	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.23, "client_ip": "127.0.0.1"}	2026-02-09 14:21:00.844302
8b7e76fd-16a5-4682-aad0-64890df3749b	INFO	POST /community/posts - 201	api	38061f08-7c0a-4f2e-831f-e25a2d54a300	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.46, "client_ip": "127.0.0.1"}	2026-02-09 14:21:01.273291
cca17dce-2e2f-4074-b6a6-fd6c5623d79c	INFO	POST /community/posts/ab5debab-05f5-46dd-ba71-9ffd02b41f35/like - 200	api	38061f08-7c0a-4f2e-831f-e25a2d54a300	{"method": "POST", "path": "/community/posts/ab5debab-05f5-46dd-ba71-9ffd02b41f35/like", "status_code": 200, "duration_ms": 7.91, "client_ip": "127.0.0.1"}	2026-02-09 14:21:01.283434
14e42c6d-42c2-496a-aed9-7bfd71dd07dc	INFO	POST /community/posts - 201	api	c8d1b59d-e711-43a7-ad87-0a664d147dbc	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.13, "client_ip": "127.0.0.1"}	2026-02-09 14:21:01.709345
893a5245-e9ed-41f3-b081-e0e114a3f667	INFO	POST /community/posts/61b3ef92-5de2-4951-aca4-ff8d3f283d62/comments - 201	api	c8d1b59d-e711-43a7-ad87-0a664d147dbc	{"method": "POST", "path": "/community/posts/61b3ef92-5de2-4951-aca4-ff8d3f283d62/comments", "status_code": 201, "duration_ms": 9.25, "client_ip": "127.0.0.1"}	2026-02-09 14:21:01.720875
824dc8f8-043a-4d06-8ffa-c02c2c74334a	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.63, "client_ip": "127.0.0.1"}	2026-02-09 14:21:02.696525
78120c1a-6c6e-46f3-8d05-f7de2fbdf7ff	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 378.28, "client_ip": "127.0.0.1"}	2026-02-10 04:38:05.465143
e1669af1-d634-462e-bb9f-abce8cc5f9d1	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 12.3, "client_ip": "127.0.0.1"}	2026-02-10 04:39:30.855282
879d8137-9270-45d1-afbe-e68346dd3b0b	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 14.47, "client_ip": "127.0.0.1"}	2026-02-10 04:40:02.99568
2a51db24-d545-4670-8ee6-4443d7793647	WARNING	GET /admin/dashboard - 401	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 401, "duration_ms": 8.61, "client_ip": "127.0.0.1"}	2026-02-18 05:52:39.033039
258483ad-b174-4376-a580-88e5c2dbb46f	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 307.21, "client_ip": "127.0.0.1"}	2026-02-18 05:52:45.454385
9c7c89c2-c44a-4c66-af55-dfa8e40738d4	INFO	POST /expert/answer - 201	api	1688162d-e838-4428-9919-3ed2d7b8e3f2	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 10.03, "client_ip": "127.0.0.1"}	2026-02-09 14:21:07.143234
dd9a66c2-dcb4-43d7-ab0f-aeca9fe75101	INFO	POST /expert/answer - 201	api	bc3179b2-9b75-4787-8e98-033ff047c171	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.06, "client_ip": "127.0.0.1"}	2026-02-09 14:21:07.789795
0bd561a1-0c78-40e1-87a9-591bb8ec4f19	WARNING	POST /expert/answer - 409	api	bc3179b2-9b75-4787-8e98-033ff047c171	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.54, "client_ip": "127.0.0.1"}	2026-02-09 14:21:07.794669
c7691d57-74a3-4bd7-9344-ba9ff5101914	WARNING	GET /expert/questions - 403	api	8777a252-90a5-4fe4-9b96-9aaa926af61a	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 46.56, "client_ip": "127.0.0.1"}	2026-02-09 14:21:08.26142
206228bb-6b57-4a73-a5dd-fcc109831c09	INFO	PUT /expert/profile - 200	api	00bcaf13-4184-4fde-87bc-b847a6e9cd6c	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.08, "client_ip": "127.0.0.1"}	2026-02-09 14:21:09.075253
afaa5ad0-5f0e-4beb-96a0-456091d3cce1	INFO	POST /farm/crops - 201	api	fbfcd28d-4b2c-40c6-8b97-a0e5e6613c0d	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 19.19, "client_ip": "127.0.0.1"}	2026-02-09 14:21:10.436222
7ddd3deb-f955-4a1c-a117-f041d781b24c	INFO	POST /farm/tasks - 201	api	0f3f0735-c312-4d64-9a57-88cbf8703bc0	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.59, "client_ip": "127.0.0.1"}	2026-02-09 14:21:11.228294
2e2a9319-d4fc-4ff4-9432-6174943c714e	INFO	POST /farm/tasks - 201	api	3e40980f-3b62-4088-9326-3aec703b97c8	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 33.59, "client_ip": "127.0.0.1"}	2026-02-09 14:21:11.641157
0857f583-277a-4d39-ad9b-fc1abd1d682a	INFO	PUT /farm/tasks/15a5595b-269d-47e2-a43c-db25faf1cfcc/complete - 200	api	3e40980f-3b62-4088-9326-3aec703b97c8	{"method": "PUT", "path": "/farm/tasks/15a5595b-269d-47e2-a43c-db25faf1cfcc/complete", "status_code": 200, "duration_ms": 5.26, "client_ip": "127.0.0.1"}	2026-02-09 14:21:11.664285
c7ea609d-65bd-47e2-904b-aee4d8bdabf7	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.67, "client_ip": "127.0.0.1"}	2026-02-09 14:21:13.021702
f0961724-72f1-4f21-bed2-27fa3c4d030c	INFO	POST /questions - 201	api	b81310df-f24d-4028-bdb5-f7b04acee536	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.64, "client_ip": "127.0.0.1"}	2026-02-09 14:21:13.389369
20092023-c82c-4081-b101-209eb9a80b9d	WARNING	POST /questions - 422	api	d5d79331-41a7-4661-84bc-a5405c1964c1	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 1.91, "client_ip": "127.0.0.1"}	2026-02-09 14:21:13.824547
1a19569f-2a6e-420d-b72d-e730a9ba8dc7	INFO	POST /questions - 201	api	a22646a0-8955-4fa6-8dc9-b25c31f1ed57	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.59, "client_ip": "127.0.0.1"}	2026-02-09 14:21:14.662244
00dfdf59-ba46-40da-95a7-d66c4d1c973f	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.58, "client_ip": "127.0.0.1"}	2026-02-09 14:21:14.820792
83ccb560-4d4a-4101-adf4-d47862df000a	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	82b2ace5-60a1-4315-8e10-b12be6711dae	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.25, "client_ip": "127.0.0.1"}	2026-02-09 14:21:15.203874
4bf37687-d95a-4649-915c-99934d558753	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 12.29, "client_ip": "127.0.0.1"}	2026-02-10 04:39:05.774653
93137363-f187-42f7-8497-9cb51a5f41f2	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.57, "client_ip": "127.0.0.1"}	2026-02-10 04:39:31.962895
87b4564a-48a6-465c-9df8-3dc83118f681	WARNING	GET /market/debug/status - 401	api	\N	{"method": "GET", "path": "/market/debug/status", "status_code": 401, "duration_ms": 2.5, "client_ip": "127.0.0.1"}	2026-02-18 06:01:58.794959
6376c019-ebd6-47d3-8b3a-226759e21981	INFO	POST /admin/experts/approve/584215fd-a619-466d-b93c-ac5653cd73d7 - 200	api	8d52e7c7-bdea-47c6-ac88-7e9e76c4a4a3	{"method": "POST", "path": "/admin/experts/approve/584215fd-a619-466d-b93c-ac5653cd73d7", "status_code": 200, "duration_ms": 3.12, "client_ip": "127.0.0.1"}	2026-02-09 14:21:26.501106
827ac529-4b9c-437d-a7a3-47cc51f8f323	WARNING	GET /admin/dashboard - 403	api	46d214ff-1f69-4d80-b248-7b973e9c0e64	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.49, "client_ip": "127.0.0.1"}	2026-02-09 14:21:28.959651
0012c3d7-fad1-4f66-a687-467c46eb8949	WARNING	GET /agronomy/diagnostic-rules - 403	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 403, "duration_ms": 0.7, "client_ip": "127.0.0.1"}	2026-02-09 14:21:30.788441
aaa8647d-0c1c-4a2a-b822-0bfe522bb8d7	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 267.8, "client_ip": "127.0.0.1"}	2026-02-09 14:21:31.163534
a8fceaa5-b18d-4ab9-ae99-2c858fb5d217	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.32, "client_ip": "127.0.0.1"}	2026-02-09 14:21:31.582667
1e5d89bf-3794-4b78-a243-b1bafa79502a	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 251.7, "client_ip": "127.0.0.1"}	2026-02-09 14:21:32.242103
e3581abf-8c44-4884-88db-c8e0eb6c9b15	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 262.95, "client_ip": "127.0.0.1"}	2026-02-09 14:21:32.93759
156aa8a1-a306-42ab-8694-46ddc7ce892d	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 3.43, "client_ip": "127.0.0.1"}	2026-02-09 14:21:33.111076
96ee9ce4-f4e7-40ba-afb9-1059730914aa	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.45, "client_ip": "127.0.0.1"}	2026-02-09 14:21:33.215188
b2ab7b90-a1f4-4792-b80c-cfeb5c6166d1	INFO	POST /community/posts - 201	api	a40745f3-c2fc-4a71-8f23-2893f629caca	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 5.56, "client_ip": "127.0.0.1"}	2026-02-09 14:21:34.423893
b4122d3c-1021-4db2-bcc6-a9e92270dbb3	WARNING	POST /community/posts - 422	api	d36ec7e7-75db-42a3-8fa5-7345b1ca074f	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 1.88, "client_ip": "127.0.0.1"}	2026-02-09 14:21:34.866253
c3b8d2e9-c579-4ba7-9970-94580ccb1cff	INFO	POST /community/posts - 201	api	ce264f24-4f2f-48ce-84f2-f36546a4d9fb	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 5.12, "client_ip": "127.0.0.1"}	2026-02-09 14:21:35.292346
e4febd9b-b067-488e-8353-9a48114e740a	INFO	POST /community/posts - 201	api	73fef3d1-d4e2-4042-b380-f5496afc510e	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.13, "client_ip": "127.0.0.1"}	2026-02-09 14:21:35.763157
21d5bfc3-7088-4438-8bd3-fb3094cf65a7	INFO	POST /community/posts/9a86f353-bfdd-40cc-94d5-365e9dfe3d64/like - 200	api	73fef3d1-d4e2-4042-b380-f5496afc510e	{"method": "POST", "path": "/community/posts/9a86f353-bfdd-40cc-94d5-365e9dfe3d64/like", "status_code": 200, "duration_ms": 7.94, "client_ip": "127.0.0.1"}	2026-02-09 14:21:35.773514
3cbf6ec3-df6c-4eb6-8f22-b5935aef9340	INFO	POST /community/posts - 201	api	575ba8bb-837e-4512-a78a-74fe3fdf1e4b	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.19, "client_ip": "127.0.0.1"}	2026-02-09 14:21:36.217538
a59dc775-3920-429b-b681-60f6071ac77c	INFO	POST /community/posts/a9edaead-3651-4247-949e-9a73ff44d4b6/comments - 201	api	575ba8bb-837e-4512-a78a-74fe3fdf1e4b	{"method": "POST", "path": "/community/posts/a9edaead-3651-4247-949e-9a73ff44d4b6/comments", "status_code": 201, "duration_ms": 6.66, "client_ip": "127.0.0.1"}	2026-02-09 14:21:36.226581
bc243c9e-5cb8-4ed9-b5f1-050b9e5d407c	INFO	PUT /farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "PUT", "path": "/farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete", "status_code": 200, "duration_ms": 111.7, "client_ip": "127.0.0.1"}	2026-02-10 04:52:36.852111
cda837bf-f1d4-4817-80dc-aaf9ed4c667f	WARNING	GET /community/posts - 401	api	\N	{"method": "GET", "path": "/community/posts", "status_code": 401, "duration_ms": 26.02, "client_ip": "127.0.0.1"}	2026-02-18 06:26:07.217816
c09ce7c3-e80a-42dc-a951-336018e4a871	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 13.78, "client_ip": "127.0.0.1"}	2026-02-18 06:26:07.285485
60b701c0-ca34-4fd9-8364-265fbaa4d7f0	WARNING	GET /admin/experts/pending - 401	api	\N	{"method": "GET", "path": "/admin/experts/pending", "status_code": 401, "duration_ms": 17.76, "client_ip": "127.0.0.1"}	2026-02-18 06:28:03.624978
15feedff-fc02-4459-aee9-f4c50af71cc2	WARNING	GET /admin/experts/pending - 401	api	\N	{"method": "GET", "path": "/admin/experts/pending", "status_code": 401, "duration_ms": 1.71, "client_ip": "127.0.0.1"}	2026-02-18 06:28:03.659832
3d13ab5c-c67f-4ab2-ba71-e26e210cd307	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 320.45, "client_ip": "127.0.0.1"}	2026-02-18 06:28:10.67358
759fa30c-84d6-4be7-be48-0bdae46f65fa	WARNING	GET /diagnosis/history - 403	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 403, "duration_ms": 0.56, "client_ip": "127.0.0.1"}	2026-02-09 14:21:37.244249
b617b4d0-5ed6-42d8-b011-ccda2ea23f6a	INFO	POST /expert/answer - 201	api	2c06f4b7-55cd-426a-9290-0b77f4979278	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 9.37, "client_ip": "127.0.0.1"}	2026-02-09 14:21:41.757972
7771c768-53b5-4cf2-b914-27810ca35386	INFO	POST /expert/answer - 201	api	e62163c9-c89e-432a-af98-3d301b1accea	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.91, "client_ip": "127.0.0.1"}	2026-02-09 14:21:42.436939
d613b605-4123-4f41-b48f-834802719ba7	WARNING	POST /expert/answer - 409	api	e62163c9-c89e-432a-af98-3d301b1accea	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.41, "client_ip": "127.0.0.1"}	2026-02-09 14:21:42.442038
2c9dcf84-0ea1-4045-bec3-8ac95fe78333	WARNING	GET /expert/questions - 403	api	57740be8-cc58-4941-9a8c-976b2c5cd501	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 45.57, "client_ip": "127.0.0.1"}	2026-02-09 14:21:42.906223
fe079f91-34e5-4d15-9ee6-03d1a01db16f	INFO	PUT /expert/profile - 200	api	c4b0d0ef-c53e-48c9-b0f1-44691d083f64	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.07, "client_ip": "127.0.0.1"}	2026-02-09 14:21:43.73821
95951533-5f17-4d18-b259-59516c57837a	INFO	POST /farm/crops - 201	api	c4461818-3a83-4ba4-ae9a-3b09c37dd150	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 15.71, "client_ip": "127.0.0.1"}	2026-02-09 14:21:44.972283
dc1452f3-37f6-4d48-a0d6-22d0861ea8b9	INFO	POST /farm/tasks - 201	api	41afbfed-9dd3-415c-9bc8-989c7025e5e5	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.94, "client_ip": "127.0.0.1"}	2026-02-09 14:21:45.779131
238e4703-5d60-4082-993b-0aa5fd3207e9	INFO	POST /farm/tasks - 201	api	5d9ba266-f95c-4c25-8162-a2bf83f0f6de	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.65, "client_ip": "127.0.0.1"}	2026-02-09 14:21:46.212204
22f56235-b996-4865-a687-7e8971619cc5	INFO	PUT /farm/tasks/89030b6d-1fed-45c8-b980-ee728916c0ff/complete - 200	api	5d9ba266-f95c-4c25-8162-a2bf83f0f6de	{"method": "PUT", "path": "/farm/tasks/89030b6d-1fed-45c8-b980-ee728916c0ff/complete", "status_code": 200, "duration_ms": 4.63, "client_ip": "127.0.0.1"}	2026-02-09 14:21:46.219022
7e43a4c4-09a3-4ee9-81d9-ca8a33218598	WARNING	GET /market/prices - 403	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 403, "duration_ms": 0.61, "client_ip": "127.0.0.1"}	2026-02-09 14:21:47.609458
422639f2-f28d-414f-bc79-2b8c4d3cc2aa	INFO	POST /questions - 201	api	554c8fa7-2b58-4e1d-ba44-8bd9d91bd995	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.58, "client_ip": "127.0.0.1"}	2026-02-09 14:21:47.9695
ba5ce611-4e58-40a4-beca-37a13d578d2f	WARNING	POST /questions - 422	api	348cf6d9-00d9-41ab-b014-02d063024803	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 1.96, "client_ip": "127.0.0.1"}	2026-02-09 14:21:48.400222
d46f7a6a-5102-4a3d-a2ba-e428b5ebb704	INFO	POST /questions - 201	api	7f4397a5-5cec-4751-bc0f-20d0178a8a4d	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.12, "client_ip": "127.0.0.1"}	2026-02-09 14:21:49.22779
b0f32a01-bf72-4fda-8758-c4cc24f9131d	WARNING	GET /questions - 403	api	\N	{"method": "GET", "path": "/questions", "status_code": 403, "duration_ms": 0.58, "client_ip": "127.0.0.1"}	2026-02-09 14:21:49.390808
ad842a25-f295-4146-ada2-f3b7d0de23b6	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	9a0722fa-2d72-46c9-8268-2071de45b282	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.17, "client_ip": "127.0.0.1"}	2026-02-09 14:21:49.742522
b0deb0ab-bdca-4311-8cb3-085f390a13f4	INFO	PUT /farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "PUT", "path": "/farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete", "status_code": 200, "duration_ms": 97.2, "client_ip": "127.0.0.1"}	2026-02-10 04:54:35.284216
6066ceb1-2ce1-446b-9fc1-f00e3030ca04	INFO	PUT /farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "PUT", "path": "/farm/tasks/3c212cfe-ac69-4669-8654-3d5643081f9a/complete", "status_code": 200, "duration_ms": 8.61, "client_ip": "127.0.0.1"}	2026-02-10 04:54:36.559581
20ab732b-a92c-4162-953a-289e91fb03e9	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 126.03, "client_ip": "127.0.0.1"}	2026-02-10 04:59:48.835977
b1d0d0e6-c7bf-4fd4-a48d-9f3a9e48ed90	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 23.05, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.425515
04940922-e831-4db0-862e-ba81646f5543	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 1.54, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.469052
6ae9c3c1-ac16-4f17-8371-4d33266402da	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 7.02, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.506339
526e93a5-b42a-4f15-ac2a-fdca3cf780a0	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 0.45, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.527936
a22d657d-302f-4f5d-8645-096b0f6bebbb	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.43, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.567331
1529d934-d011-4e4b-949f-dd01c63fe4f9	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 342.22, "client_ip": "127.0.0.1"}	2026-02-10 05:00:12.814637
f07443e6-e108-44fb-8a3e-6265ead53ddb	WARNING	GET /market/prices - 401	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 401, "duration_ms": 21.02, "client_ip": "127.0.0.1"}	2026-02-18 06:57:40.947284
ec76a3ff-6c30-404d-9bb0-7941bdca9b5a	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 20.45, "client_ip": "127.0.0.1"}	2026-02-18 06:57:41.023329
dbbc5f91-ce3d-40ea-88cc-78e32f15957e	WARNING	GET /expert/trending-diseases - 401	api	\N	{"method": "GET", "path": "/expert/trending-diseases", "status_code": 401, "duration_ms": 37.28, "client_ip": "127.0.0.1"}	2026-02-09 14:23:40.602992
0ece8d65-8f26-4a94-8215-57d0c38ace3e	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 11.69, "client_ip": "127.0.0.1"}	2026-02-09 14:23:40.700218
a28a5d57-9b3c-4bb5-8174-61cfa7fa0e92	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 8.22, "client_ip": "127.0.0.1"}	2026-02-10 05:00:05.561321
ac6e0393-dfbc-4d09-901f-b78c724a46cf	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 349.61, "client_ip": "127.0.0.1"}	2026-02-19 14:26:20.356442
b03d2a8e-a838-434f-aa20-9062a5d97d36	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 24.22, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.753409
ba78e09e-db86-4580-907d-e0bbe849a126	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 0.77, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.817332
e0bf7f1d-91fc-4805-b565-37944cbac5b3	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.07, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.845684
5632fd19-f58e-4460-9f0d-7f0578167c1a	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.47, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.875283
adf7a317-7530-47f3-a2ce-b0b72458d453	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 0.39, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.90244
3864d0ea-1d92-495c-bf06-434d3f6ae294	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 330.37, "client_ip": "127.0.0.1"}	2026-02-09 15:38:48.616
3ca11f6f-bf99-4e4b-be81-bd5687448669	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 15.62, "client_ip": "127.0.0.1"}	2026-02-09 15:39:51.04787
e4971be6-2a66-455c-98e3-c7b95410c91d	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 376.12, "client_ip": "127.0.0.1"}	2026-02-10 05:11:45.967844
8fe0e794-7c89-4e74-b3aa-4cf66824cb7d	INFO	POST /auth/token - 200	api	\N	{"method": "POST", "path": "/auth/token", "status_code": 200, "duration_ms": 293.23, "client_ip": "127.0.0.1"}	2026-02-10 05:11:59.511423
e530c4c8-78a5-46b1-9f05-04238f42cc09	INFO	POST /diagnosis/predict - 200	api	53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 56.43, "client_ip": "127.0.0.1"}	2026-02-10 05:12:57.807625
7ed19738-9b59-4e38-93e1-025699ff6b51	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 343.16, "client_ip": "127.0.0.1"}	2026-02-19 15:31:22.761923
d71c7d87-573d-4a37-ba52-01e08ceeea5a	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 1.45, "client_ip": "127.0.0.1"}	2026-02-09 15:38:41.89707
029ae292-f7ba-4e96-81bb-f291f155d9e7	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 77.98, "client_ip": "127.0.0.1"}	2026-02-09 15:39:24.688355
638b45f2-fd3c-4672-8155-faceb177a88b	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 466.3, "client_ip": "127.0.0.1"}	2026-02-09 15:39:37.752232
366d124f-5c54-4291-b379-a363480a6e3f	INFO	POST /admin/experts/approve/88522851-f999-48d7-812b-d1524e1e946d - 200	api	23bd0d78-a43c-497c-80cd-5eb2496d864f	{"method": "POST", "path": "/admin/experts/approve/88522851-f999-48d7-812b-d1524e1e946d", "status_code": 200, "duration_ms": 3.25, "client_ip": "127.0.0.1"}	2026-02-10 05:17:30.321963
bef0d8a2-7a2c-4d68-a652-b73043e0325c	WARNING	GET /admin/dashboard - 403	api	f03aa387-08e0-41e2-b02c-7282c007e8a8	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.5, "client_ip": "127.0.0.1"}	2026-02-10 05:17:32.518505
5bef8769-370d-4b88-8ec9-8f50430d0cfa	WARNING	GET /agronomy/diagnostic-rules - 401	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 401, "duration_ms": 0.73, "client_ip": "127.0.0.1"}	2026-02-10 05:17:34.627187
0baef7da-8d73-43bb-8fa9-fda44b8f907d	WARNING	POST /auth/token - 401	api	\N	{"method": "POST", "path": "/auth/token", "status_code": 401, "duration_ms": 45.73, "client_ip": "127.0.0.1"}	2026-02-19 15:40:33.175899
5f3dccfc-ccff-46f0-8e82-48f160a16064	WARNING	GET /market/debug/status - 401	api	\N	{"method": "GET", "path": "/market/debug/status", "status_code": 401, "duration_ms": 1.42, "client_ip": "127.0.0.1"}	2026-02-19 15:40:33.206065
fda36350-a3c6-4e9f-8ea4-4ddce2bc77bc	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 2.4, "client_ip": "127.0.0.1"}	2026-02-09 15:43:39.104704
a1ec0538-1f5e-4d22-a64c-8c101eb0f1bd	INFO	POST /admin/experts/approve/083b22a3-8d5a-45ce-aa8b-11aff0c57cb6 - 200	api	32386e35-04a8-40ec-be71-193b1fa1cf6e	{"method": "POST", "path": "/admin/experts/approve/083b22a3-8d5a-45ce-aa8b-11aff0c57cb6", "status_code": 200, "duration_ms": 3.73, "client_ip": "127.0.0.1"}	2026-02-10 05:18:14.079692
8a090f07-a012-4ff9-9ace-2298ec24c706	WARNING	GET /admin/dashboard - 403	api	4c8dd7aa-4dd4-4320-a04b-45f1c83dae17	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.74, "client_ip": "127.0.0.1"}	2026-02-10 05:18:16.177911
f520c32f-33b7-4756-98b7-2700c7629669	WARNING	GET /agronomy/diagnostic-rules - 401	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 401, "duration_ms": 0.83, "client_ip": "127.0.0.1"}	2026-02-10 05:18:18.014013
e2f66654-ab36-4bbb-9cf8-8f402f258de2	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 262.04, "client_ip": "127.0.0.1"}	2026-02-10 05:18:18.398628
22e4353c-04e0-4f6c-a920-21d65e5dd255	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.15, "client_ip": "127.0.0.1"}	2026-02-10 05:18:18.810153
538c3766-260a-46a5-a9d8-f5ec2d5dfcbe	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 245.24, "client_ip": "127.0.0.1"}	2026-02-10 05:18:19.483491
7e4635aa-f3d4-4f0a-a29c-f74fc80559e6	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 246.34, "client_ip": "127.0.0.1"}	2026-02-10 05:18:20.174898
bd16b95f-4611-4122-948c-733e8ee17a93	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 3.18, "client_ip": "127.0.0.1"}	2026-02-10 05:18:20.303691
5e053fcb-0061-40c5-8c57-5fc15ddf9dcc	WARNING	GET /diagnosis/history - 401	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 401, "duration_ms": 0.62, "client_ip": "127.0.0.1"}	2026-02-10 05:18:20.439194
40214d4a-0746-4b40-ac05-c227626192f2	INFO	POST /community/posts - 201	api	b449135a-c9f8-42fe-ab7a-55b312a04182	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 8.1, "client_ip": "127.0.0.1"}	2026-02-10 05:18:21.782033
ad77c935-8948-48e5-bcd2-5c96819ac4e5	WARNING	POST /community/posts - 422	api	f86ad8f7-af8d-4ce3-a603-0656d907d2d0	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 2.71, "client_ip": "127.0.0.1"}	2026-02-10 05:18:22.22209
1d3dbf2c-8dc9-4b5a-a772-37819119215a	INFO	POST /community/posts - 201	api	773a3075-cb25-4575-9265-cf85fdb75afe	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.63, "client_ip": "127.0.0.1"}	2026-02-10 05:18:22.672678
93030a94-c829-47d4-a06c-f44b81c35664	INFO	POST /community/posts - 201	api	f73a9fda-7210-45a4-bc18-e2cb65e8d46c	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.53, "client_ip": "127.0.0.1"}	2026-02-10 05:18:23.101631
5e343bc9-0a24-4ffe-b4f1-5ff35720f556	INFO	POST /community/posts/cc6f7a3c-5d1d-4d99-8322-cc68abfba93e/like - 200	api	f73a9fda-7210-45a4-bc18-e2cb65e8d46c	{"method": "POST", "path": "/community/posts/cc6f7a3c-5d1d-4d99-8322-cc68abfba93e/like", "status_code": 200, "duration_ms": 7.59, "client_ip": "127.0.0.1"}	2026-02-10 05:18:23.111702
4002c229-f010-4f2a-9fda-86bedb7a1657	INFO	POST /community/posts - 201	api	a9d62d92-c1f8-4d8a-9631-5a0387e416f0	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 6.42, "client_ip": "127.0.0.1"}	2026-02-10 05:18:23.555733
6ebe69a6-9e37-4a85-8059-7b74e8cbd93e	INFO	POST /community/posts/2a9fb3ee-ae5c-47ce-ab7d-5998828e13e9/comments - 201	api	a9d62d92-c1f8-4d8a-9631-5a0387e416f0	{"method": "POST", "path": "/community/posts/2a9fb3ee-ae5c-47ce-ab7d-5998828e13e9/comments", "status_code": 201, "duration_ms": 7.44, "client_ip": "127.0.0.1"}	2026-02-10 05:18:23.565761
78e0b02f-0759-4afb-be7a-89c840a46a37	WARNING	GET /diagnosis/history - 401	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 401, "duration_ms": 0.65, "client_ip": "127.0.0.1"}	2026-02-10 05:18:24.557452
33c81791-3aaa-4603-b7ba-bb2811c15b71	INFO	POST /expert/answer - 201	api	886a95d0-e561-42aa-8ec3-cc737653cb97	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.92, "client_ip": "127.0.0.1"}	2026-02-10 05:18:28.931068
18c66c38-2bfa-4c4a-8123-a03a532d22f8	INFO	POST /expert/answer - 201	api	05415f74-a016-45d9-a573-893527175477	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 6.72, "client_ip": "127.0.0.1"}	2026-02-10 05:18:29.66682
80f1ec20-3c42-4884-87af-21d2d1522244	WARNING	POST /expert/answer - 409	api	05415f74-a016-45d9-a573-893527175477	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.16, "client_ip": "127.0.0.1"}	2026-02-10 05:18:29.671074
77dff388-2c34-4589-b839-70d5598144cb	WARNING	GET /expert/questions - 403	api	32fb1aa5-344a-468d-97cb-e5736713f103	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 1.95, "client_ip": "127.0.0.1"}	2026-02-10 05:18:30.095739
a679253d-1740-4b15-b022-006b8dc4fbbe	INFO	PUT /expert/profile - 200	api	13c2fd26-07d8-4880-862d-7f39bd4a15c7	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.0, "client_ip": "127.0.0.1"}	2026-02-10 05:18:30.931448
ab8e3f63-2b29-479e-8b59-fea11a216c86	INFO	POST /farm/crops - 201	api	d2837c91-1923-42dd-9b1e-3f4acd80baf0	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 20.02, "client_ip": "127.0.0.1"}	2026-02-10 05:18:32.2914
6b3b728c-cc7e-46ef-85f7-4227ea01654a	INFO	POST /farm/tasks - 201	api	31975846-9cf2-43c3-90a4-8e6ba3b57562	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 21.56, "client_ip": "127.0.0.1"}	2026-02-10 05:18:33.129256
d04fd0fb-3e92-4d32-987d-ac09568f26eb	INFO	POST /farm/tasks - 201	api	97788d40-b7d6-462f-874b-f14a149d689b	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.88, "client_ip": "127.0.0.1"}	2026-02-10 05:18:33.554252
fd319a8a-0e7f-4481-947c-e174a9d9e38b	INFO	PUT /farm/tasks/f7bee12f-32bf-485a-bbc7-541743d6e709/complete - 200	api	97788d40-b7d6-462f-874b-f14a149d689b	{"method": "PUT", "path": "/farm/tasks/f7bee12f-32bf-485a-bbc7-541743d6e709/complete", "status_code": 200, "duration_ms": 4.71, "client_ip": "127.0.0.1"}	2026-02-10 05:18:33.561199
41ba0ccf-5aeb-48c6-ae2d-e4e28a2196ef	WARNING	GET /market/prices - 401	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 401, "duration_ms": 0.66, "client_ip": "127.0.0.1"}	2026-02-10 05:18:35.011779
fbf68b19-622c-402c-ba2b-a3fc638a8986	INFO	POST /questions - 201	api	4c08aed2-ec7f-4c1e-8993-d592e73dc56e	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.02, "client_ip": "127.0.0.1"}	2026-02-10 05:18:35.539213
306624a3-ce05-4183-a439-0d8b6c6b337a	WARNING	POST /questions - 422	api	2e65e64a-c7fd-49dd-8705-19f87bea960e	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 1.84, "client_ip": "127.0.0.1"}	2026-02-10 05:18:35.95209
ead14c1a-d6c0-4f09-944f-fafdf5eada56	INFO	POST /questions - 201	api	b5215ef4-a10a-4fc5-afb7-38ab9c37e4e0	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 6.95, "client_ip": "127.0.0.1"}	2026-02-10 05:18:36.823563
a1fe9fb1-c7ef-4da4-b8f9-517c566ecd20	WARNING	GET /questions - 401	api	\N	{"method": "GET", "path": "/questions", "status_code": 401, "duration_ms": 0.88, "client_ip": "127.0.0.1"}	2026-02-10 05:18:37.022313
44e59b44-50f4-4b09-b1e5-0a5a21856453	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	fb292f40-76fc-4bef-9f5e-f6c928384d55	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.99, "client_ip": "127.0.0.1"}	2026-02-10 05:18:37.565803
9876a0b4-2a53-44c1-aedf-99d18befe69c	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 351.45, "client_ip": "127.0.0.1"}	2026-02-19 15:50:33.694099
cc8ae9c3-b3af-4644-b69d-9205226af4f9	WARNING	POST /diagnosis/predict - 403	api	\N	{"method": "POST", "path": "/diagnosis/predict", "status_code": 403, "duration_ms": 2.17, "client_ip": "127.0.0.1"}	2026-02-09 15:46:12.324455
f887c793-8900-47ee-aafa-718b2c70a849	WARNING	POST /diagnosis/predict - 403	api	\N	{"method": "POST", "path": "/diagnosis/predict", "status_code": 403, "duration_ms": 2.32, "client_ip": "127.0.0.1"}	2026-02-09 15:50:09.880321
7730d97d-8dd6-4957-ae13-0183720ff183	INFO	POST /admin/experts/approve/7e5f5a43-cd7c-4b4e-b85b-509b8a730c9c - 200	api	c47a1647-4d8d-4de1-9394-c8b3e1bb1250	{"method": "POST", "path": "/admin/experts/approve/7e5f5a43-cd7c-4b4e-b85b-509b8a730c9c", "status_code": 200, "duration_ms": 3.35, "client_ip": "127.0.0.1"}	2026-02-10 05:19:31.245789
7f41ccab-2c04-4d5e-8bd0-ac5e2ea57043	WARNING	GET /admin/dashboard - 403	api	7c719e26-73cd-45ac-aef5-18a47af731fb	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.78, "client_ip": "127.0.0.1"}	2026-02-10 05:19:33.426424
6f64a0fb-8aeb-47bb-a76b-2fb18eed261d	WARNING	GET /agronomy/diagnostic-rules - 401	api	\N	{"method": "GET", "path": "/agronomy/diagnostic-rules", "status_code": 401, "duration_ms": 0.69, "client_ip": "127.0.0.1"}	2026-02-10 05:19:35.294221
925ed80d-efd6-451f-99b8-4d7b8c70f6ba	INFO	POST /auth/register - 201	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 201, "duration_ms": 263.16, "client_ip": "127.0.0.1"}	2026-02-10 05:19:35.709062
42ff797c-cc97-4576-a2aa-5b0dc10fd8fd	WARNING	POST /auth/register - 409	api	\N	{"method": "POST", "path": "/auth/register", "status_code": 409, "duration_ms": 2.45, "client_ip": "127.0.0.1"}	2026-02-10 05:19:36.108921
b602aaaf-f21e-4d01-8fce-6e9a11282fe3	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 268.57, "client_ip": "127.0.0.1"}	2026-02-10 05:19:36.81199
de497ed7-465a-43e8-82fc-2ad0dfe48996	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 266.01, "client_ip": "127.0.0.1"}	2026-02-10 05:19:37.650647
7f0d0c3f-d23a-4812-8b11-d42975064047	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 5.6, "client_ip": "127.0.0.1"}	2026-02-10 05:19:37.886195
ec7455ff-c5d8-4895-b206-71cec5e88552	WARNING	GET /diagnosis/history - 401	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 401, "duration_ms": 0.59, "client_ip": "127.0.0.1"}	2026-02-10 05:19:38.091542
c8639905-544f-47f2-9553-5cbef69ffcfb	INFO	POST /community/posts - 201	api	ddaa4f3b-5057-40aa-a918-59857bf7c8ec	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 7.1, "client_ip": "127.0.0.1"}	2026-02-10 05:19:39.379533
977aece5-402a-462e-84e4-9618322f21e1	WARNING	POST /community/posts - 422	api	eff9bf83-94e5-4b98-96eb-b10d31ac12d2	{"method": "POST", "path": "/community/posts", "status_code": 422, "duration_ms": 3.1, "client_ip": "127.0.0.1"}	2026-02-10 05:19:39.821973
d3c2d105-b73f-4b64-8478-5e928e1dc409	INFO	POST /community/posts - 201	api	f2a49a4f-d7f3-4d9a-965e-c12817c94270	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 7.01, "client_ip": "127.0.0.1"}	2026-02-10 05:19:40.268793
a8f7cee7-feb3-401d-8c27-b6365936ff72	INFO	POST /community/posts - 201	api	0217e20b-cd91-4e4d-9f17-5096924c41d8	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 7.26, "client_ip": "127.0.0.1"}	2026-02-10 05:19:40.715055
98027d40-0bfb-470a-8a99-a895961101e9	INFO	POST /community/posts/29350311-0a10-4881-9cde-6479a3ae12c4/like - 200	api	0217e20b-cd91-4e4d-9f17-5096924c41d8	{"method": "POST", "path": "/community/posts/29350311-0a10-4881-9cde-6479a3ae12c4/like", "status_code": 200, "duration_ms": 9.43, "client_ip": "127.0.0.1"}	2026-02-10 05:19:40.728074
fee562ba-0b03-4585-87cf-b997dab4715e	INFO	POST /community/posts - 201	api	23a24586-9b74-474a-8a55-5008dd9d0713	{"method": "POST", "path": "/community/posts", "status_code": 201, "duration_ms": 10.71, "client_ip": "127.0.0.1"}	2026-02-10 05:19:41.187969
972d56ff-cda5-4993-8914-e9ce3cc5d38b	INFO	POST /community/posts/3e603b0d-5396-474f-a50f-21fb9b08fd72/comments - 201	api	23a24586-9b74-474a-8a55-5008dd9d0713	{"method": "POST", "path": "/community/posts/3e603b0d-5396-474f-a50f-21fb9b08fd72/comments", "status_code": 201, "duration_ms": 7.21, "client_ip": "127.0.0.1"}	2026-02-10 05:19:41.197574
4b8d2de0-1927-4ad6-9a04-17b192db6005	WARNING	GET /diagnosis/history - 401	api	\N	{"method": "GET", "path": "/diagnosis/history", "status_code": 401, "duration_ms": 0.52, "client_ip": "127.0.0.1"}	2026-02-10 05:19:42.274932
f210deef-99bd-4c0a-98b0-086c0a75d0d0	INFO	POST /expert/answer - 201	api	6696a6fa-8672-4f0d-a868-dfdbeb3c5d11	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.65, "client_ip": "127.0.0.1"}	2026-02-10 05:19:47.289143
c91ae7f7-a848-4a8b-bfcb-78ff0c12c6d7	INFO	POST /expert/answer - 201	api	83ebb725-ef30-41a8-97c2-96b2557c56fe	{"method": "POST", "path": "/expert/answer", "status_code": 201, "duration_ms": 8.09, "client_ip": "127.0.0.1"}	2026-02-10 05:19:48.001016
2a8040d5-f526-4909-8934-1df398c9dc37	WARNING	POST /expert/answer - 409	api	83ebb725-ef30-41a8-97c2-96b2557c56fe	{"method": "POST", "path": "/expert/answer", "status_code": 409, "duration_ms": 2.52, "client_ip": "127.0.0.1"}	2026-02-10 05:19:48.006443
0163970a-d68b-4841-9aae-0f043f6c35cf	WARNING	GET /expert/questions - 403	api	5c7ea89c-2181-4f3d-ac5e-bb6cdc57511f	{"method": "GET", "path": "/expert/questions", "status_code": 403, "duration_ms": 1.54, "client_ip": "127.0.0.1"}	2026-02-10 05:19:48.440822
1f924222-e760-439d-a79d-333485eec4f6	INFO	PUT /expert/profile - 200	api	3ca77490-de76-4c29-ba98-291207cae352	{"method": "PUT", "path": "/expert/profile", "status_code": 200, "duration_ms": 2.23, "client_ip": "127.0.0.1"}	2026-02-10 05:19:49.31483
b112fced-7d41-4c53-a1a3-87a1e762b40d	INFO	POST /farm/crops - 201	api	6bee09ec-31bf-4cdf-bb43-045c1b75b46c	{"method": "POST", "path": "/farm/crops", "status_code": 201, "duration_ms": 20.71, "client_ip": "127.0.0.1"}	2026-02-10 05:19:50.739944
5ce40537-06ef-4356-81cc-8196d4dc24a6	INFO	POST /farm/tasks - 201	api	50431682-750c-4da7-96c9-c9e7eeaf7e46	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 20.46, "client_ip": "127.0.0.1"}	2026-02-10 05:19:51.660387
27a4d8d2-e853-4d63-9fd4-1748b6a36697	INFO	POST /farm/tasks - 201	api	2f332e69-50a2-4eb1-bd0e-845089d13840	{"method": "POST", "path": "/farm/tasks", "status_code": 201, "duration_ms": 81.39, "client_ip": "127.0.0.1"}	2026-02-10 05:19:52.202783
d09b41cf-7850-4a07-b9c8-ebe01491f646	INFO	PUT /farm/tasks/c08808c7-c811-47da-a2be-a320c234d889/complete - 200	api	2f332e69-50a2-4eb1-bd0e-845089d13840	{"method": "PUT", "path": "/farm/tasks/c08808c7-c811-47da-a2be-a320c234d889/complete", "status_code": 200, "duration_ms": 4.95, "client_ip": "127.0.0.1"}	2026-02-10 05:19:52.210167
f4af0ec4-036d-4444-999c-e4fa42750710	WARNING	GET /market/prices - 401	api	\N	{"method": "GET", "path": "/market/prices", "status_code": 401, "duration_ms": 0.77, "client_ip": "127.0.0.1"}	2026-02-10 05:19:54.042306
0770800a-11cc-4e30-8313-85b65ef1ac30	INFO	POST /questions - 201	api	32bcc8e7-5756-4709-9161-d9d96ee10f59	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 54.71, "client_ip": "127.0.0.1"}	2026-02-10 05:19:54.8909
84c06aa0-990b-42f8-8fd4-7891283cfc4f	WARNING	POST /questions - 422	api	6a26d86e-ce55-4216-8ced-737be85cb549	{"method": "POST", "path": "/questions", "status_code": 422, "duration_ms": 11.24, "client_ip": "127.0.0.1"}	2026-02-10 05:19:55.982262
aaf2b6e3-5145-434a-a27b-04d8dbb10ce0	WARNING	POST /ml/predict - 404	api	\N	{"method": "POST", "path": "/ml/predict", "status_code": 404, "duration_ms": 1.99, "client_ip": "127.0.0.1"}	2026-02-09 15:51:50.810846
488f2315-3840-4d85-a538-7f921532391a	WARNING	POST /diagnosis/predict - 403	api	\N	{"method": "POST", "path": "/diagnosis/predict", "status_code": 403, "duration_ms": 12.8, "client_ip": "127.0.0.1"}	2026-02-09 15:59:43.464232
a40c3ec7-177c-43e6-a02f-9c6fa8bf1c06	INFO	POST /agronomy/validate-diagnosis - 200	api	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	{"method": "POST", "path": "/agronomy/validate-diagnosis", "status_code": 200, "duration_ms": 99.29, "client_ip": "127.0.0.1"}	2026-02-09 16:01:07.437157
f1754b4b-1ff4-425c-9098-9d343b55e9e0	WARNING	POST /diagnosis/mock_1770653025276/rate - 400	api	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	{"method": "POST", "path": "/diagnosis/mock_1770653025276/rate", "status_code": 400, "duration_ms": 46.69, "client_ip": "127.0.0.1"}	2026-02-09 16:03:53.922105
f39aac34-5125-4751-9068-fb23545c9528	INFO	POST /questions - 201	api	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 83.78, "client_ip": "127.0.0.1"}	2026-02-09 16:05:53.745626
7dd939d5-cc80-4b1b-9a7d-3609a4d43a1b	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 112.48, "client_ip": "127.0.0.1"}	2026-02-09 16:09:39.483603
83117868-cda8-465d-bff5-dd1dcffb1b2a	INFO	POST /auth/refresh - 200	api	\N	{"method": "POST", "path": "/auth/refresh", "status_code": 200, "duration_ms": 19.83, "client_ip": "127.0.0.1"}	2026-02-09 16:09:40.013377
0ab9343f-acfd-420f-a3ac-1a88c6e7a6fa	WARNING	GET /auth/me - 401	api	\N	{"method": "GET", "path": "/auth/me", "status_code": 401, "duration_ms": 30.9, "client_ip": "127.0.0.1"}	2026-02-09 16:10:49.056206
738864b0-263f-480b-8789-cccd8315569f	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 7.15, "client_ip": "127.0.0.1"}	2026-02-09 16:10:49.12726
6b28a44e-a778-47da-9efb-73999f63f4e5	WARNING	GET /admin/dashboard - 403	api	\N	{"method": "GET", "path": "/admin/dashboard", "status_code": 403, "duration_ms": 1.47, "client_ip": "127.0.0.1"}	2026-02-09 16:10:49.168276
f8d08e4f-ca7d-4dae-a86d-bae280862210	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 3.36, "client_ip": "127.0.0.1"}	2026-02-09 16:10:49.201923
dc8159b0-65b1-4244-bf86-fb75ac231c82	INFO	POST /diagnosis/predict - 200	api	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 35.65, "client_ip": "127.0.0.1"}	2026-02-09 16:12:55.182789
72149f7f-52aa-4979-9254-0caf0da3bc20	INFO	POST /questions - 201	api	69e39071-9830-45fc-aa5b-6923db0f5779	{"method": "POST", "path": "/questions", "status_code": 201, "duration_ms": 5.94, "client_ip": "127.0.0.1"}	2026-02-10 05:19:57.129397
cde751d6-1e8e-4c9b-b90a-ebc59d6eb5f3	WARNING	GET /questions - 401	api	\N	{"method": "GET", "path": "/questions", "status_code": 401, "duration_ms": 0.48, "client_ip": "127.0.0.1"}	2026-02-10 05:19:57.273833
356a8edf-5364-4a57-a175-4f53dc9561f9	WARNING	GET /questions/00000000-0000-0000-0000-000000000000 - 404	api	2abd19cb-45df-40f6-bde4-5742ad5d7b62	{"method": "GET", "path": "/questions/00000000-0000-0000-0000-000000000000", "status_code": 404, "duration_ms": 3.38, "client_ip": "127.0.0.1"}	2026-02-10 05:19:57.62503
ea95adbe-9c6c-4784-9b6b-b2c6f9267eaf	WARNING	GET /admin/metrics/daily - 403	api	\N	{"method": "GET", "path": "/admin/metrics/daily", "status_code": 403, "duration_ms": 2.66, "client_ip": "127.0.0.1"}	2026-02-09 16:10:49.406292
e08b30b2-58ca-4bc1-b118-a02bdb177e25	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 340.08, "client_ip": "127.0.0.1"}	2026-02-09 16:10:55.792952
f50d25d9-f010-4671-af9b-90bde5994234	INFO	POST /diagnosis/predict - 200	api	77e5e0cc-8d0a-42c3-b162-904cfbc8896f	{"method": "POST", "path": "/diagnosis/predict", "status_code": 200, "duration_ms": 83.47, "client_ip": "127.0.0.1"}	2026-02-09 16:12:37.262987
5f85e2e3-d2df-4b6f-95ef-e74cf10e445f	WARNING	POST /auth/login - 401	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 401, "duration_ms": 38.65, "client_ip": "127.0.0.1"}	2026-02-10 05:20:11.509213
405fe890-68a2-4716-a404-77d19c5c4d94	INFO	POST /auth/login - 200	api	\N	{"method": "POST", "path": "/auth/login", "status_code": 200, "duration_ms": 309.98, "client_ip": "127.0.0.1"}	2026-02-10 05:20:16.425269
ab3fcfc0-05bb-4f92-b846-1d4e3f8554a9	WARNING	GET /agronomy/treatment-constraints - 404	api	ad4863d1-3073-4606-8100-999fe3b3942e	{"method": "GET", "path": "/agronomy/treatment-constraints", "status_code": 404, "duration_ms": 20.19, "client_ip": "127.0.0.1"}	2026-02-09 13:19:24.158734
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.system_metrics (id, metric_name, metric_value, metric_type, tags, recorded_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: akshayks
--

COPY public.users (id, email, password_hash, full_name, phone, role, status, is_verified, otp_code, otp_created_at, expertise_domain, qualification, experience_years, location, created_at, updated_at) FROM stdin;
f4296aed-3c19-48ab-96ac-e542cd545e47	admin@cropdiagnosis.com	$2b$12$UlCbcWN4e7x1N.LcZ5vzvuBtMNvb0PuvWY6hSP07Ow31Xd8Sec7ja	System Admin	+91-9999999999	ADMIN	ACTIVE	t	\N	\N	\N	\N	\N	\N	2026-01-31 14:23:14.689934	2026-01-31 14:23:14.689939
53bc36f5-1bf6-4a0c-9774-f8f7f046e4ed	farmer1@example.com	$2b$12$kj2fnWK9bX6yrPGmv/MeWeP8JS.Rb2TDUIxX05fQVMYTBdQMsm37S	Raju Kumar	+91-9876543210	FARMER	ACTIVE	t	\N	\N	\N	\N	\N	Karnataka, India	2026-01-31 14:23:14.689944	2026-01-31 14:23:14.689944
77e5e0cc-8d0a-42c3-b162-904cfbc8896f	farmer2@example.com	$2b$12$XAjdFtTaG0VloTKXyFpipeSwxV51AjOzXtcNX3koN2SOida6EO41a	Lakshmi Devi	+91-9876543211	FARMER	ACTIVE	t	\N	\N	\N	\N	\N	Tamil Nadu, India	2026-01-31 14:23:14.689948	2026-01-31 14:23:14.689948
ad4863d1-3073-4606-8100-999fe3b3942e	expert1@example.com	$2b$12$wwqqzojU56ste./ljkUmROfKWGw9i/Cd7ZTd8EguvVJjhqgMXQjMy	Dr. Anil Sharma	+91-9988776655	EXPERT	ACTIVE	t	\N	\N	Tomato & Potato Diseases	PhD in Plant Pathology	15	\N	2026-01-31 14:23:14.689952	2026-01-31 14:23:14.689952
5ef812e0-a4ad-4927-8ed4-0e5cde06dd51	expert2@example.com	$2b$12$8MQzVd9LIwJaSYv7.RM6Ou89NYkEXWUKRfnpy5TOrHNjcufLcvtxm	Dr. Priya Patel	+91-9988776656	EXPERT	PENDING	t	\N	\N	Rice & Wheat Diseases	MSc Agriculture	8	\N	2026-01-31 14:23:14.689955	2026-01-31 14:23:14.689956
1ddb77c7-5db3-4d9b-837b-2dd5bb76cb98	farmer3@example.com	$2b$12$AjXKm2rFiK2jwB344JS6j.7N0Dn8C/kHYdIg41Uswekil5n8XooSi	farmer3	\N	FARMER	ACTIVE	t	\N	\N	\N	\N	\N	\N	2026-02-10 09:10:15.610493	2026-02-10 09:10:28.56759
\.


--
-- Name: agronomy_diagnostic_rules agronomy_diagnostic_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_diagnostic_rules
    ADD CONSTRAINT agronomy_diagnostic_rules_pkey PRIMARY KEY (id);


--
-- Name: agronomy_seasonal_patterns agronomy_seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_seasonal_patterns
    ADD CONSTRAINT agronomy_seasonal_patterns_pkey PRIMARY KEY (id);


--
-- Name: agronomy_treatment_constraints agronomy_treatment_constraints_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_treatment_constraints
    ADD CONSTRAINT agronomy_treatment_constraints_pkey PRIMARY KEY (id);


--
-- Name: answers answers_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_pkey PRIMARY KEY (id);


--
-- Name: community_comments community_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.community_comments
    ADD CONSTRAINT community_comments_pkey PRIMARY KEY (id);


--
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- Name: crop_encyclopedia crop_encyclopedia_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.crop_encyclopedia
    ADD CONSTRAINT crop_encyclopedia_pkey PRIMARY KEY (id);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (id);


--
-- Name: diagnoses diagnoses_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.diagnoses
    ADD CONSTRAINT diagnoses_pkey PRIMARY KEY (id);


--
-- Name: disease_encyclopedia disease_encyclopedia_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.disease_encyclopedia
    ADD CONSTRAINT disease_encyclopedia_pkey PRIMARY KEY (id);


--
-- Name: farm_crops farm_crops_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.farm_crops
    ADD CONSTRAINT farm_crops_pkey PRIMARY KEY (id);


--
-- Name: farm_tasks farm_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.farm_tasks
    ADD CONSTRAINT farm_tasks_pkey PRIMARY KEY (id);


--
-- Name: market_prices market_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.market_prices
    ADD CONSTRAINT market_prices_pkey PRIMARY KEY (id);


--
-- Name: pest_encyclopedia pest_encyclopedia_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.pest_encyclopedia
    ADD CONSTRAINT pest_encyclopedia_pkey PRIMARY KEY (id);


--
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_agronomy_treatment_constraints_treatment_name; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_agronomy_treatment_constraints_treatment_name ON public.agronomy_treatment_constraints USING btree (treatment_name);


--
-- Name: ix_answers_expert_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_answers_expert_id ON public.answers USING btree (expert_id);


--
-- Name: ix_answers_question_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_answers_question_id ON public.answers USING btree (question_id);


--
-- Name: ix_community_comments_post_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_community_comments_post_id ON public.community_comments USING btree (post_id);


--
-- Name: ix_community_posts_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_community_posts_user_id ON public.community_posts USING btree (user_id);


--
-- Name: ix_crop_encyclopedia_name; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE UNIQUE INDEX ix_crop_encyclopedia_name ON public.crop_encyclopedia USING btree (name);


--
-- Name: ix_daily_stats_date; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE UNIQUE INDEX ix_daily_stats_date ON public.daily_stats USING btree (date);


--
-- Name: ix_diagnoses_created_at; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_diagnoses_created_at ON public.diagnoses USING btree (created_at);


--
-- Name: ix_diagnoses_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_diagnoses_user_id ON public.diagnoses USING btree (user_id);


--
-- Name: ix_disease_encyclopedia_name; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_disease_encyclopedia_name ON public.disease_encyclopedia USING btree (name);


--
-- Name: ix_farm_crops_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_farm_crops_user_id ON public.farm_crops USING btree (user_id);


--
-- Name: ix_farm_tasks_crop_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_farm_tasks_crop_id ON public.farm_tasks USING btree (crop_id);


--
-- Name: ix_farm_tasks_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_farm_tasks_user_id ON public.farm_tasks USING btree (user_id);


--
-- Name: ix_market_prices_commodity; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_market_prices_commodity ON public.market_prices USING btree (commodity);


--
-- Name: ix_market_prices_location; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_market_prices_location ON public.market_prices USING btree (location);


--
-- Name: ix_pest_encyclopedia_name; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_pest_encyclopedia_name ON public.pest_encyclopedia USING btree (name);


--
-- Name: ix_post_likes_post_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_post_likes_post_id ON public.post_likes USING btree (post_id);


--
-- Name: ix_post_likes_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_post_likes_user_id ON public.post_likes USING btree (user_id);


--
-- Name: ix_questions_created_at; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_questions_created_at ON public.questions USING btree (created_at);


--
-- Name: ix_questions_farmer_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_questions_farmer_id ON public.questions USING btree (farmer_id);


--
-- Name: ix_system_logs_created_at; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_logs_created_at ON public.system_logs USING btree (created_at);


--
-- Name: ix_system_logs_level; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_logs_level ON public.system_logs USING btree (level);


--
-- Name: ix_system_logs_source; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_logs_source ON public.system_logs USING btree (source);


--
-- Name: ix_system_logs_user_id; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_logs_user_id ON public.system_logs USING btree (user_id);


--
-- Name: ix_system_metrics_metric_name; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_metrics_metric_name ON public.system_metrics USING btree (metric_name);


--
-- Name: ix_system_metrics_recorded_at; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE INDEX ix_system_metrics_recorded_at ON public.system_metrics USING btree (recorded_at);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: akshayks
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: agronomy_diagnostic_rules agronomy_diagnostic_rules_disease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_diagnostic_rules
    ADD CONSTRAINT agronomy_diagnostic_rules_disease_id_fkey FOREIGN KEY (disease_id) REFERENCES public.disease_encyclopedia(id);


--
-- Name: agronomy_seasonal_patterns agronomy_seasonal_patterns_crop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_seasonal_patterns
    ADD CONSTRAINT agronomy_seasonal_patterns_crop_id_fkey FOREIGN KEY (crop_id) REFERENCES public.crop_encyclopedia(id);


--
-- Name: agronomy_seasonal_patterns agronomy_seasonal_patterns_disease_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.agronomy_seasonal_patterns
    ADD CONSTRAINT agronomy_seasonal_patterns_disease_id_fkey FOREIGN KEY (disease_id) REFERENCES public.disease_encyclopedia(id);


--
-- Name: answers answers_expert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_expert_id_fkey FOREIGN KEY (expert_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: answers answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: community_comments community_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.community_comments
    ADD CONSTRAINT community_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- Name: community_comments community_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.community_comments
    ADD CONSTRAINT community_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: community_posts community_posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: diagnoses diagnoses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.diagnoses
    ADD CONSTRAINT diagnoses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: farm_crops farm_crops_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.farm_crops
    ADD CONSTRAINT farm_crops_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: farm_tasks farm_tasks_crop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.farm_tasks
    ADD CONSTRAINT farm_tasks_crop_id_fkey FOREIGN KEY (crop_id) REFERENCES public.farm_crops(id) ON DELETE SET NULL;


--
-- Name: farm_tasks farm_tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.farm_tasks
    ADD CONSTRAINT farm_tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: questions questions_diagnosis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_diagnosis_id_fkey FOREIGN KEY (diagnosis_id) REFERENCES public.diagnoses(id) ON DELETE SET NULL;


--
-- Name: questions questions_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: akshayks
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 7xPZWawhW4hPBSz9vfB3p07EC9FHKPjenNdt0aMUl0b1ay8P7ASbzyR2D7ePUOg

